package com.cts.classifiedsportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassifiedsPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
