insert into employee(emp_id,emp_email,emp_name) values(1,'john@gmail.com','john');
insert into employee(emp_id,emp_email,emp_name) values(2,'jessy@gmail.com','jessy');
insert into employee(emp_id,emp_email,emp_name) values(3,'riya@gmail.com','riya');
insert into employee(emp_id,emp_email,emp_name) values(4,'maya@gmail.com','maya');
insert into employee(emp_id,emp_email,emp_name) values(5,'arya@gmail.com','arya');

