package com.cts.offermicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfferMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
