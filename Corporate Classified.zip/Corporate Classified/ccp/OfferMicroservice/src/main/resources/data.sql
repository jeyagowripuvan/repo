insert into offer_category values(120,'Homes');
insert into offer_category values(121,'Vehicles');
insert into offer_category values(122,'Electronics');
insert into offer_category values(123,'Home Appliances');
insert into offer_category values(124,'Mobiles & Tablets');
insert into offer_category values(125,'Furniture & Decors');
insert into offer_category values(126,'Commercial Rentals');