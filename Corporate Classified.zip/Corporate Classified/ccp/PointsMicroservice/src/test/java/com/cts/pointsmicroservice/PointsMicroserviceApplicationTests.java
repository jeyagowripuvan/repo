package com.cts.pointsmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PointsMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
