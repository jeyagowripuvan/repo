/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package smallindustries;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class Valid {
    public int validIndustry(String indname)
    {
        try {
            // TODO add your handling code here:
            Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/small" , "root","priyajeyah"); 
            System.out.println("Connected");
            Statement statement1 = conn.createStatement();
            ResultSet rst = statement1.executeQuery("SELECT * FROM restriction");
             //ResultSetMetaData rsmd1 = rst.getMetaData();
             //int columnsNumber1 = rsmd1.getColumnCount();
             //int id;
             while(rst.next())
             {
                 System.out.println(rst.getString(1));
                 if(rst.getString(1).equals(indname))
                 {
                     /*JFrame f=new JFrame();
                     JOptionPane.showMessageDialog(f,"Only small industries are allowed!!!!!");
                     //break;
                     Login l=new Login();
                     l.setVisible(true);
                     break;*/
                     return 1;
                 }}
          //   return 0;
    }
        catch(Exception e)
        {
            System.out.println(e);
        }
 return 0;   
}
}