/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.BufferedReader;
//import Imagere.Imagere;
import java.io.PrintStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
/**
 *
 * @author HP
 */
public class Server {
    public static void main(String args[]) throws Exception
{
    ServerSocket s=new ServerSocket(6758);
System.out.println("socket created");
Socket sk=s.accept();
System.out.println("accepted");
String msg,msg1;
BufferedReader in=new BufferedReader(new InputStreamReader(sk.getInputStream()));
PrintStream out=new PrintStream(sk.getOutputStream());
BufferedReader user=new BufferedReader(new InputStreamReader(System.in));
while(true){
String g;
g=in.readLine();
System.out.println("g:"+g);
if(g.equals("submit"))
{
msg=in.readLine();
msg1=in.readLine();
String msg2=in.readLine();
try{
    Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
       Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/memory" ,"root","priyajeyah");     
       PreparedStatement pst = conn.prepareStatement("insert into player(no,name,score) values(?,?,?)");
       System.out.println("Connected");
       pst.setString(1, msg);
         pst.setString(2, msg1);
         pst.setString(3,"1000");
         //boolean r=pst.execute();
        int r=pst.executeUpdate();
        // pst.executeQuery();
       System.out.println(r);
      if (r==1)
         {
          out.println("ok");
            // s.close();
             //out.close();
             //in.close();
             //System.out.println("ok1");
         }
}
catch(Exception e)
{
    System.out.println(e);
}
}
else if(g.equals("4X4"))
{
try{
    Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
       Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/memory" ,"root","priyajeyah");     
      PreparedStatement ps=conn.prepareStatement("select * from four");  
System.out.println("statement");
   ArrayList<ArrayList<String>> outer = new ArrayList<ArrayList<String>>();
ArrayList<String> inner=new ArrayList<String>();
ResultSet rs=ps.executeQuery(); 
ResultSetMetaData rsmd = rs.getMetaData();
int columnsNumber = rsmd.getColumnCount();
String col=Integer.toString(columnsNumber);
out.println(col);
while(rs.next()){//now on 1st row   
    for(int i=1; i<=columnsNumber-1; i++){
       inner.add(rs.getString(2));
     //  System.out.println(inner);
       // out.println(inner);
    }    }
    outer.add(inner);
    System.out.println(inner);
   // new fourcrossfour(inner);
    /* String[] files1=new String[inner.size()];
       files1=inner.toArray(files1);
       System.out.println("\nfiles1:"+files1);
       String f=files1.toString();
    new fourcrossfour(files1);*/
   // System.out.println(inner);
    //System.out.println("Adde");
      out.println(inner);
          out.println("ok");
           //  s.close();
            // out.close();
             //in.close();
             //System.out.println("ok1");
         
}
catch(Exception e)
{
    System.out.println(e);
}
}
else if(g.equals("6X6"))
{
 try{
    Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
       Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/memory" ,"root","priyajeyah");     
      PreparedStatement ps=conn.prepareStatement("select * from six");  
System.out.println("statement");
   ArrayList<ArrayList<String>> outer = new ArrayList<ArrayList<String>>();
ArrayList<String> inner=new ArrayList<String>();
ResultSet rs=ps.executeQuery(); 
ResultSetMetaData rsmd = rs.getMetaData();
int columnsNumber = rsmd.getColumnCount();
String col=Integer.toString(columnsNumber);
out.println(col);
while(rs.next()){//now on 1st row   
    for(int i=1; i<=columnsNumber-1; i++){
       inner.add(rs.getString(2));
     //  System.out.println(inner);
       // out.println(inner);
    }    }
    outer.add(inner);
   // System.out.println(inner);
    //System.out.println("Adde");
        out.println(inner);
          out.println("ok");
           //  s.close();
            // out.close();
             //in.close();
             //System.out.println("ok1");
         
}
catch(Exception e)
{
    System.out.println(e);
}   
}
}
}
}
