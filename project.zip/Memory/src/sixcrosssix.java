
//import static fourcrossfour.sc;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class sixcrosssix extends JFrame{
    static JButton buttons[];
    static String[] words;
    static JTextField sc;
    ImageIcon closedIcon;
    JFrame f1;
    int numButtons;
    ImageIcon icons[];
    Timer myTimer;
    static int score=1000;
    int numClicks = 0;
    int oddClickIndex = 0;
    int currentIndex = 0;
    JTextField sco1;
    public sixcrosssix(String files){
        JPanel p=new JPanel();
       JPanel p2=new JPanel();
       JPanel p3=new JPanel();
     words = files.split(" ");
     int n=words.length;
     int n1=words[n-1].length();
    // System.out.println(n1);
        words[0]=words[0].substring(1);
         words[n-1]=words[n-1].substring(0,n1-1);
     for(int i=0;i<words.length;i++)
     {
         words[i]=words[i].replaceAll(",$", "");
     }
        //System.out.println(Arrays.toString(words));
        f1=new JFrame();
          f1.setTitle("Memory Game");

        // Specify an action for the close button.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
sco1=new JTextField();
       p2.add(sco1,BorderLayout.EAST);
        
        
        // Create a BorderLayout manager.
        p.setLayout(new GridLayout(6, (words.length)));

        closedIcon = new ImageIcon("D:\\New folder\\memory.jpg");
        numButtons = (words.length) * 2;
   
        buttons = new JButton[numButtons];
        icons = new ImageIcon[numButtons];
        sc=new JTextField();
        for (int i = 0, j = 0; i < words.length; i++) {
            //System.out.println("For");
            //String f=files.get(i).toString();
            //System.out.println("icons"+words[i]);
            icons[j] = new ImageIcon(words[i]);
            buttons[j] = new JButton("");
            //System.out.println("button");
            buttons[j].addActionListener(new ImageButtonListener());
            buttons[j].setIcon(closedIcon);
            p.add(buttons[j++]);

            icons[j] = icons[j - 1];
            buttons[j] = new JButton("");
            buttons[j].addActionListener(new ImageButtonListener());
            buttons[j].setIcon(closedIcon);
            p.add(buttons[j++]);
        }
        p.setSize(900,900);
       // add(sc);
        // randomize icons array
        Random gen = new Random();
        for (int i = 0; i < numButtons; i++) {
            int rand = gen.nextInt(numButtons);
            ImageIcon temp = icons[i];
            icons[i] = icons[rand];
            icons[rand] = temp;
        }
        
         p3.add(p);
         p3.add(p2);
         p3.setLayout(new GridLayout(1,2));
         f1.add(p3);
         f1.setSize(1000,1000);
        // Pack and display the window.
        pack();
        f1.setVisible(true);

        myTimer = new Timer(1000, new TimerListener());
        // myTimer.start();
        //JOptionPane.showMessageDialog(null,"Score"+score);
    }

    private class TimerListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            buttons[currentIndex].setIcon(closedIcon);
            buttons[oddClickIndex].setIcon(closedIcon);
            myTimer.stop();
        }
    }

    private class ImageButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            
            // we are waiting for timer to pop - no user clicks accepted
            if (myTimer.isRunning())
                return;
            
            numClicks++;
            System.out.println(numClicks);
            
            // which button was clicked?
            for (int i = 0; i < numButtons; i++) {
                if (e.getSource() == buttons[i]) {
                    buttons[i].setIcon(icons[i]);
                    currentIndex = i;
                }
            }
            
            if (numClicks % 2 == 0) {
                // check whether same position is clicked twice!
                if (currentIndex == oddClickIndex) {
                    numClicks--;
                    return;
                }
                // are two images matching?
                if (icons[currentIndex] != icons[oddClickIndex]) {
                    // show images for 1 sec, before flipping back
                    score=score-20;
                    myTimer.start(); 
                }
                else
                {
                    score=score+100;
                }
            } else {
                // we just record index for odd clicks
                oddClickIndex = currentIndex;
                //score=score+100;
            }
            String sco=Integer.toString(score);
            sco1.setText("Your Score:"+sco);
        }
    }
    
   
    public static void main(String arg[])
    {
        //new fourcrossfour()
    }
    
}
