
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Image1 extends JFrame{
    public static void main(String args[])
    {
        try{
            Socket sk=new Socket("127.0.0.1",1331);
            System.out.println("socket1 created");
            BufferedReader in=new BufferedReader(new InputStreamReader(sk.getInputStream()));
            PrintStream out=new PrintStream(sk.getOutputStream());
            BufferedReader user=new BufferedReader(new InputStreamReader(System.in));
//String s;

out.println("4X4");
// String s1=jTextField1.getText();
  //      String s2=jTextField2.getText();
       // out.println(s1);

//out.println(s2);
String st;
st=in.readLine();
System.out.print("Server : "+st+"\n");
int n=Integer.parseInt(st);
for(int i=0;i<n;i++)
{
                String files=in.readLine();
                System.out.println(files);
}
if(st.equals("ok")){
JOptionPane.showMessageDialog(null,"login successfully");
        }}
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    }
    

