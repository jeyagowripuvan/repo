//package fourcrossfour;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.Timer;
import javax.swing.JOptionPane;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class fourcrossfour extends JFrame{
    static JButton buttons[];
    static String[] words;
    JFrame f;
    JLabel pic3;
    static JTextField sc;
    ImageIcon closedIcon;
    int numButtons;
    ImageIcon icons[];
    Timer myTimer;
    Timer timer1;
    public static int score=1000;
    int numClicks = 0;
    int oddClickIndex = 0;
    int currentIndex = 0;
    public fourcrossfour(String files){
       JPanel p=new JPanel();
       JPanel p2=new JPanel();
       JPanel p3=new JPanel();
       // System.out.println("Files"+files);
   words = files.split(" ");
     int n=words.length;
    // System.out.println("n:"+n);
     int n1=words[n-1].length();
     //System.out.println("n1:"+n1);
        words[0]=words[0].substring(1);
         words[n-1]=words[n-1].substring(0,n1-1);
     for(int i=0;i<words.length;i++)
     {//System.out.println("For");
         words[i]=words[i].replaceAll(",$", "");
     }
     f=new JFrame();
      //  System.out.println(Arrays.toString(words));
          f.setTitle("Memory Game");
         /*  pic3=new JLabel();
        pic3.setBounds(0, 0, 700, 700);
        ImageIcon image3=SetImageSize3();
        add(pic3);
        pic3.setIcon(image3);*/

        // Specify an action for the close button.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
 //JPanel p2=new JPanel();       // Create a BorderLayout manager.
        sc=new JTextField();
        sc.setBounds(100,100,100,100);
       // JLabel l1=new JLabel(new ImageIcon("D:\\New folder\\memory.jpg"));
        //p2.add(l1);
       /*  */
        
       p2.add(sc,BorderLayout.EAST);
      /* JLabel pic3=new JLabel();
        pic3.setBounds(100, 100, 100, 100);
        ImageIcon image3=SetImageSize3();
        p2.add(pic3);
        System.out.println("Addes");
        pic3.setIcon(image3);
        p2.add(sc);*/
        //p2.setBackground(Color.red);
        p.setLayout(new GridLayout(4, (words.length)));
        
        
        closedIcon = new ImageIcon("D:\\New folder\\memory.jpg");
        numButtons = (words.length) * 2;
   
        buttons = new JButton[numButtons];
        icons = new ImageIcon[numButtons];
      
        for (int i = 0, j = 0; i < words.length; i++) {
            //System.out.println("For");
            //String f=files.get(i).toString();
            //System.out.println("icons"+words[i]);
            icons[j] = new ImageIcon(words[i]);
            buttons[j] = new JButton("");
            //System.out.println("button");
            buttons[j].addActionListener(new ImageButtonListener());
            buttons[j].setIcon(closedIcon);
            p.add(buttons[j++]);

            icons[j] = icons[j - 1];
            buttons[j] = new JButton("");
            buttons[j].addActionListener(new ImageButtonListener());
            buttons[j].setIcon(closedIcon);
            p.add(buttons[j++]);
        }
        p.setBounds(40,80,900,900);
        
       // add(sc);

        // randomize icons array
        Random gen = new Random();
        for (int i = 0; i < numButtons; i++) {
            int rand = gen.nextInt(numButtons);
            ImageIcon temp = icons[i];
            icons[i] = icons[rand];
            icons[rand] = temp;
        }
        
         p3.add(p);
         p3.add(p2);
         p3.setLayout(new GridLayout(1,2));
        // Pack and display the window.
        pack();
        f.add(p3);
        f.setSize(1000,1000);
        f.setVisible(true);

        myTimer = new Timer(1000, new TimerListener());
        timer1=new Timer(5000,new TimerListen());
        myTimer.start();
      //  JOptionPane.showMessageDialog(null,"Score"+score);
    }
    /*public ImageIcon SetImageSize3(){
                System.out.println("\nfrozen");
            ImageIcon icon3=new ImageIcon("D:\\New folder\\nature-wallpaper.jpg");
            Image img3=icon3.getImage();
            Image newImg3 = img3.getScaledInstance(pic3.getWidth(), pic3.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon newImc3=new ImageIcon(newImg3);
             System.out.println("akdadw");
            return newImc3;
            }*/

    private class TimerListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            //System.out.println("timelistener");
            buttons[currentIndex].setIcon(closedIcon);
            buttons[oddClickIndex].setIcon(closedIcon);
            myTimer.stop();
        }
    }
    private class TimerListen implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            buttons[currentIndex].setIcon(closedIcon);
            buttons[oddClickIndex].setIcon(closedIcon);
            timer1.stop();
        }
    }


    private class ImageButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
          //  JOptionPane.showMessageDialog(null,"score");
            
            // we are waiting for timer to pop - no user clicks accepted
            if (myTimer.isRunning())
                return;
            
            numClicks++;
            System.out.println(numClicks);
            
            // which button was clicked?
            for (int i = 0; i < numButtons; i++) {
                if (e.getSource() == buttons[i]) {
                   
                    buttons[i].setIcon(icons[i]);
                    currentIndex = i;
                }
            }
            
            if (numClicks % 2 == 0) {
                // check whether same position is clicked twice!
                if (currentIndex == oddClickIndex) {
                 
                    numClicks--;
                    return;
                }
                if (icons[currentIndex] != icons[oddClickIndex]) {
                    // show images for 1 sec, before flipping back
                    score=score-20;
                    myTimer.start(); 
                }
                else
                {
                    score=score+100;
                }
            } else {
                oddClickIndex = currentIndex;
            }
            //JTextField sc=new JTextField();
            String sco=Integer.toString(score);
            sc.setText("Your score:"+sco);
           // System.out.println("Score"+score);
        
       
        }
      // String sc="Score"+score;
     // JOptionPane.showMessageDialog(null,sc); 
    }
     /*public ImageIcon SetImageSize3(){
               // System.out.println("\nfrozen");
            ImageIcon icon3=new ImageIcon("D:\\New folder\\nature-wallpaper.jpg");
            java.awt.Image img3=icon3.getImage();
            java.awt.Image newImg3 = img3.getScaledInstance(pic3.getWidth(), pic3.getHeight(), java.awt.Image.SCALE_SMOOTH);
            ImageIcon newImc3=new ImageIcon(newImg3);
      
            return newImc3;
            }*/
    
   
    public static void main(String arg[])
    {
        //new fourcrossfour()
    }
}

