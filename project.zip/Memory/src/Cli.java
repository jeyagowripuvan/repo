
import javax.swing.JFrame;
import javax.swing.JLabel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
    import java.awt.Color;
import java.awt.Image;
import javax.swing.*;


public class Cli extends JFrame{
    //JFrame frame;
    JLabel pic3;
    //JLabel pic1,pic2,pic3;
    //JLabel pic6,pic7,pic8;
    public Cli()
    {
        //int x=0;
        super("Java Resize Image");
         
        
        pic3=new JLabel();
        pic3.setBounds(0, 0, 400, 400);
        ImageIcon image3=SetImageSize3();
        add(pic3);
        pic3.setIcon(image3);
        JButton easy=new JButton("Easy");
        easy.setBounds(150, 80, 100, 50);
        add(easy);
        JButton medium=new JButton("Medium");
        medium.setBounds(150,150,100,50);
        add(medium);
        JButton hard=new JButton("Hard");
        hard.setBounds(150,230,100,50);
        add(hard);
        setLayout(null);
        setSize(400,400);
        getContentPane().setBackground(Color.decode("#bdb67b"));
        
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    
}
    public ImageIcon SetImageSize3()
    {
        ImageIcon icon3=new ImageIcon("D:\\New folder\\nature-wallpaper.jpg");
            Image img3=icon3.getImage();
            Image newImg3 = img3.getScaledInstance(pic3.getWidth(), pic3.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon newImc3=new ImageIcon(newImg3);
      
            return newImc3;
    }

    public static void main(String args[])
    {
        new Cli();
    }
            }

