package car;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Sys {

  public Integer system_id;

  public String system_name;
  String pi,mail;

  public void generatePin(String cno,int sid,String hour) {
      Mask m=new Mask();
      pi=m.generateRandomPassword();
      System.out.println("The generated pin is:"+pi);
      try
      {
          Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
          Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah"); 
          String query2="update driver set pin=? where car_no='"+cno+"'";
          PreparedStatement pst2=(PreparedStatement) conn.prepareStatement(query2);
          pst2.setString(1,pi);
          pst2.executeUpdate();
          String query3="select mail_id from driver where car_no='"+cno+"'";
          Statement stmt=conn.createStatement();
          ResultSet rs=stmt.executeQuery(query3);
          ResultSetMetaData rsmd = rs.getMetaData();
          int columnsNumber = rsmd.getColumnCount();
          while (rs.next()){
              for(int k = 1 ; k <= columnsNumber; k++)
           {
               mail=rs.getString(k);
               //System.out.print(rs.getString(k) + " "); 
           }
          
         }
          System.out.println("Your ticket:");
          System.out.println("Car no\t\tSlot id\t\tArrival time\t\tDeparture time");
          String did=hour.substring(0,2);
          hour=hour.substring(0,2)+":"+hour.substring(2);
          //System.out.println(hour);
          int deid=Integer.parseInt(did);
          deid=deid+1;
          //String sr=hour.substring(2);
          //System.out.println(sr);
          did=deid+hour.substring(2);
          System.out.println(cno+"\t"+sid+"\t\t"+hour+"\t\t\t"+did);
          Sys s=new Sys();
          s.notifyDriver(pi,mail);
          
      }
      catch(Exception e)
      {
          e.printStackTrace();
      }
  }

  public void generateReport() {
       try{
           int flag=0;
       Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
       Connection conn1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah");     
       System.out.println("The report is:");
       DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
       Date date = new Date();
       String date1=dateFormat.format(date);
       String query2="select * from payment where date='"+date1+"'";
       Statement stmt=conn1.createStatement();
       ResultSet rs=stmt.executeQuery(query2);
       ResultSetMetaData rsmd = rs.getMetaData();
       int columnsNumber = rsmd.getColumnCount();
       System.out.println("Payment Id\tAmount\t\tDate\t\t\tCar No\t\t\tSystem id");
       while (rs.next())
       {
           for(int k = 1 ; k <= columnsNumber; k++)
           {
               System.out.print(rs.getString(k) + "\t\t"); 
           }
           System.out.println();
           flag=1;
       }
       if(flag==0)
       {
       System.out.println("No report available");
       }
       Sys s=new Sys();
       s.enterChoice();
       }
       catch(Exception e){
            e.printStackTrace();
        }
  }

  public void notifyDriver(String sec,String mail) {
      Notify n=new Notify();
      n.sendMail("srijeya2331@gmail.com",mail,"Your car is parked successfully.Your security pin is",sec+"<br>Please don't share it with others!!");
      Sys s=new Sys();
      s.enterChoice();
  }

  public void enterChoice() {
      System.out.println("Welcome!!!Please make sure your mail is open!!!");
      System.out.println("...........................................");
      System.out.println("1.Access free slot");
      System.out.println("2.Unpark car");
      System.out.println("3.Admin");
      System.out.println("...........................................");
      System.out.println("Enter choice");
      Scanner s=new Scanner(System.in);
      int ch=s.nextInt();
      switch(ch)
      {
          case 1:
              Slot sl=new Slot();
              sl.displayFreeSlot();
              break;
          case 2:
             Driver d=new Driver();
             d.enterPin();
             break;
          case 3:
              Admin a=new Admin();
              a.login();
              break;
          default:
              System.out.println("Enter valid choice:");
              Sys sy=new Sys();
              sy.enterChoice();
              break;
      }
  }
  /*public static void main(String[] args)
  {
      Sys s=new Sys();
      s.generateReport();
  }*/
}