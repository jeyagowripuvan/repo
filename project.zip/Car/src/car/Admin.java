package car;
import java.sql.Connection;
import java.util.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.io.*;

public class Admin {

  public String user_name;

  public String password;

   // public Vector  *;

  public void login() {
       try
       {
           int i=0;
           while(i<3)
           {
               Scanner s=new Scanner(System.in);
               System.out.println("Enter the username:");
               String username=s.next();
               System.out.println("Enter the password:");
               String password=s.next();
               Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
               Connection conn1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah");     
               PreparedStatement pst = conn1.prepareStatement("Select * from admin where user_name=? and password=?");
               pst.setString(1, username); 
               pst.setString(2, password);
               ResultSet rs = pst.executeQuery();                        
               if(rs.next())
               {
                   System.out.println("Login successful");   
                   Admin a=new Admin();
                   a.viewReport();
                   break;
               }
               else
               {
                   System.out.println("Enter username and password correctly");
                   i++;
               }
           }
       }
       catch(ClassNotFoundException | SQLException e)
       {
           e.printStackTrace();
       }
}

  public void viewReport() {
      Sys s=new Sys();
      s.generateReport();
  }
}