/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author HP
 */
public class SlotValid {
    public int validSlot(int sid)
    {
        try
        {
           Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
          Connection conn1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah");
            String query="select slot_id from slot where car_no IS NULL";
          Statement stmt1=conn1.createStatement();
          ResultSet rs1=stmt1.executeQuery(query);
          ResultSetMetaData rsmd2 = rs1.getMetaData();
          int columnsNumber1 = rsmd2.getColumnCount();
          while (rs1.next()) 
          {
              //System.out.println("eeeeee");
              for(int j = 1 ; j <= columnsNumber1; j++)
              {
                  //System.out.println(rs1.getString(j));
                  if(sid==Integer.parseInt(rs1.getString(j)))
                  {
                   //   System.out.println("success");
                      return 1;
                      //cid=d.enterDetails();
                      //break;
                  }
        }
    }
        }
         catch(ClassNotFoundException | SQLException e)
      {
       e.printStackTrace();
      }
 //return 0;       
        return 0;
}
}
