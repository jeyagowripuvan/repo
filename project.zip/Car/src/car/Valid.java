/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;
import java.util.*;
import java.util.regex.Pattern;

/**
 *
 * @author HP
 */
public class Valid {

public static boolean validateMail(String mail)
{
     String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                            "[a-zA-Z0-9_+&*-]+)*@" + 
                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                            "A-Z]{2,7}$"; 
                              
        Pattern pat = Pattern.compile(emailRegex); 
        if (mail == null) 
            return false; 
        return pat.matcher(mail).matches(); 
    }
public static boolean validateCar(String car)
{
    String emailRegex = "^([a-zA-Z]+[a-zA-Z])" + 
                            "([0-9]+[0-9])+[a-z" + 
                            "A-Z]{1,2}+([0-9]{1,4})$"; 
                              
        Pattern pat = Pattern.compile(emailRegex); 
        if (car == null) 
            return false; 
        return pat.matcher(car).matches(); 
    
}
/*public static void main(String[] args)
{
    boolean cvalid=validateCar("TN5TT56");
    if(cvalid)
    {
        System.out.println("yes");
        
    }
    else
    {
        System.out.println("No");
    }
}*/

    
}
