package car;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Timer {

  public Integer arrival_time;

  public Integer departure_time;

   // public Vector  1;

  public void calculateTime(int sid,String cno) {
      try
      {
          Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
          Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah"); 
          String query3="select arrival_time from timer where timer_id='"+sid+"'";
          Statement stmt=conn.createStatement();
          ResultSet rs=stmt.executeQuery(query3);
          ResultSetMetaData rsmd = rs.getMetaData();
          int columnsNumber = rsmd.getColumnCount();
          String det;
          while (rs.next())
          {
              for(int k = 1 ; k <= columnsNumber; k++)
              {
                  String de=rs.getString(k);
                  if(de.length()==3)
                  {
                      det="0"+de.substring(0,1);
                  }
                  else
                  {
                      det=de.substring(0, 2);
                  }
                  arrival_time=Integer.parseInt(det);
              }
          }
          String det1;
          String query4="select departure_time from timer where timer_id='"+sid+"'";
          Statement stmt1=conn.createStatement();
          ResultSet rs1=stmt1.executeQuery(query4);
          ResultSetMetaData rsmd1 = rs1.getMetaData();
          int columnsNumber1 = rsmd1.getColumnCount();
          while (rs1.next())
          {
              for(int j = 1 ; j <= columnsNumber1; j++)
              {
                  String de1=rs1.getString(j);
                  if(de1.length()==3)
                  {
                      det1="0"+de1.substring(0,1);
                  }
                  else
                  {
                      det1=de1.substring(0, 2);
                  }
                  departure_time=Integer.parseInt(det1);
              }
          }
          int totaltime=departure_time-arrival_time;
          Payment p=new Payment();
          p.handlePayment(totaltime,sid,cno);
      }
      catch(Exception e)
      {
          e.printStackTrace();
      }
  }

  public void startTimer(int sid,String cno) {
        DateFormat dateFormat = new SimpleDateFormat("HHmm");
	Date date = new Date();
	String hour=dateFormat.format(date);
        try
        {
            Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah"); 
            String query1="insert into timer(timer_id,arrival_time) values(?,?)";
            PreparedStatement pst1=(PreparedStatement) conn.prepareStatement(query1);
            pst1.setInt(1,sid);
            pst1.setString(2, hour);
            pst1.executeUpdate();
            String query2="update slot set timer_id=? where slot_id='"+sid+"'";
            PreparedStatement pst2=(PreparedStatement) conn.prepareStatement(query2);
            pst2.setInt(1,sid);
            pst2.executeUpdate();
            Sys s=new Sys();
            s.generatePin(cno,sid,hour);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        } 
  }

  public void stopTimer(int sid,String cno) {
      DateFormat dateFormat1 = new SimpleDateFormat("HHmm");
      Date date1 = new Date();
      String hour=dateFormat1.format(date1);
      try
      {
          Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
          Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah"); 
          String query2="update timer set departure_time=? where timer_id='"+sid+"'";
          PreparedStatement pst2=(PreparedStatement) conn.prepareStatement(query2);
          pst2.setString(1,hour);
          pst2.executeUpdate();
          Timer t=new Timer();
          t.calculateTime(sid,cno);
      }
      catch(Exception e)
      {
          e.printStackTrace();
      }
  }
}