package car;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Scanner;

public class Driver {

  public String car_no;

  public String mail_id;

   // public Vector  1;
  //  public Vector  1;
Scanner s=new Scanner(System.in);
  public String enterDetails() {
      System.out.println("Enter your car number:");
      car_no=s.next();
      Valid v=new Valid();
      boolean valid=v.validateCar(car_no);
      if(!valid)
      {
          System.out.println("Please check your car number!!!!");
          Driver d=new Driver();
          d.enterDetails();
      }
      System.out.println("Enter your mail id:");
      mail_id=s.next();
      boolean mail_valid=v.validateMail(mail_id);
      if(!mail_valid)
      {
          System.out.println("Enter valid mail id please!!!!");
          System.out.println("The mail format is:name@mail.com");
          Driver d=new Driver();
          d.enterDetails();
      }
      try{
            Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah"); 
            //System.out.println("Connected");
             String query="insert into driver(car_no,mail_id) values(?,?)";
            PreparedStatement pst=(PreparedStatement) conn.prepareStatement(query);
            pst.setString(1,car_no);
            pst.setString(2,mail_id);
            pst.executeUpdate();
            //System.out.println("Inserted successfully");
      }
      catch(Exception e)
        {
            e.printStackTrace();
        }
            return car_no;    
}

  public int enterSlot() {
      System.out.println("Enter the slot:");
      int slot=s.nextInt();
      return slot;
  }

  public void enterPin() {
      Scanner s=new Scanner(System.in);
      System.out.println("Enter the slot:");
      int sid=s.nextInt();
      System.out.println("Enter the car no");
      String cno=s.next();
      Valid v=new Valid();
      boolean cvalid=v.validateCar(cno);
      if(!cvalid)
      {
          System.out.println("Enter the valid car no plssssss!!!!!");
          Driver d=new Driver();
          d.enterPin();
      }
      System.out.println("Enter the secret pin:");
      String pin=s.next();
      try
      {
          int flag=1;
          Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
          Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah"); 
          String query2="select pin from driver where car_no='"+cno+"'";
          Statement stmt=conn.createStatement();
          ResultSet rs=stmt.executeQuery(query2);
          ResultSetMetaData rsmd = rs.getMetaData();
          int columnsNumber = rsmd.getColumnCount();
          while (rs.next()) 
          {
              for(int k = 1 ; k <= columnsNumber; k++)
              {
                  if(pin.equals(rs.getString(k)))
                  {
                      System.out.println("You can unpark your car!!!!Thanks,Visit us again!!!!");
                    //  flag=0;
                  }
                  else
                  {
                      //System.out.println("Enter valid pin");
                      flag=0;
                  }
              }
          }
          if(flag==0)
          {
              System.out.println("Enter valid pin!!!!");
              Driver d=new Driver();
              d.enterPin();
          }
          Timer t=new Timer();
          t.stopTimer(sid,cno);
      }
      catch(Exception e)
      {
          e.printStackTrace();
      }
  }
}