package car;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
public class Slot {

  public Integer slot_id;

  public void displayFreeSlot() {
      try
      {
          String cid=null;
          int id = 0;
          Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
          Connection conn1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah");     
          System.out.println("The available slots are:");
          String query2="select slot_id from slot where car_no IS NULL;";
          Statement stmt=conn1.createStatement();
          ResultSet rs=stmt.executeQuery(query2);
          ResultSetMetaData rsmd = rs.getMetaData();
          int columnsNumber = rsmd.getColumnCount();
          while (rs.next())
          {
              for(int k = 1 ; k <= columnsNumber; k++)
              {
                  System.out.print(rs.getString(k) + " ");
              }
              System.out.println();
          }
          Driver d=new Driver();
          int flag=1;
          id=d.enterSlot();
          SlotValid sv=new SlotValid();
          int y=sv.validSlot(id);
          //System.out.println("Valid:"+y);
         /* String query="select slot_id from slot where car_no IS NULL";
          Statement stmt1=conn1.createStatement();
          ResultSet rs1=stmt1.executeQuery(query);
          ResultSetMetaData rsmd2 = rs1.getMetaData();
          int columnsNumber1 = rsmd2.getColumnCount();
          while (rs1.next()) 
          {
              System.out.println("eeeeee");
              for(int j = 1 ; j <= columnsNumber1; j++)
              {
                  System.out.println(rs1.getString(j));
                  if(id==Integer.parseInt(rs1.getString(j)))
                  {
                      System.out.println("success");
                      cid=d.enterDetails();
                      //break;
                  }
                 // break;
                  else
                  {
                      flag=0;
                  }
                break;
              }
             break;
              
          }
          if(flag==0)
          {
              System.out.println("Enter available slots please!!");
              Slot sl=new Slot();
              sl.displayFreeSlot();
            //  break;
          }
          else{*/
         if(y==1)
         {
             Driver dr=new Driver();
             cid=dr.enterDetails();
         }
         else
         {
             System.out.println("Enter available slots please!!!");
             Slot s=new Slot();
             s.displayFreeSlot();
         }
          String jid=Integer.toString(id);
          String query1="update slot set car_no=?"+"where slot_id='"+jid+"'";
          PreparedStatement pst1=(PreparedStatement) conn1.prepareStatement(query1);
          pst1.setString(1,cid);
          pst1.executeUpdate();
          Timer t=new Timer();
          t.startTimer(id,cid);
       }
      catch(ClassNotFoundException | SQLException e)
      {
       e.printStackTrace();
      }
  }
}