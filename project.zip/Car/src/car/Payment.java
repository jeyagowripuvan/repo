package car;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Vector;

public class Payment {

  public Integer pay_id;
  public Integer amount;
  public String payment_date;

   // public Vector  1;
   // public Vector  1;

  public void handlePayment(int total,int sid,String cno) {
      if(total==0)
      {
          amount=50;   
      }
      else if(total>1)
      {
          amount=total*50;
      }
      DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
      Date date = new Date();
      payment_date=dateFormat.format(date);
      System.out.println("The total amount is:"+amount);
      System.out.println("Please pay it at the counter!!!");
      pay_id=(int)(Math.random()*500)+1;
      
      //System.out.println(pay_id);
      try
      {
          Class.forName("com.mysql.jdbc.Driver");  // MySQL database connection
          Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/car" , "root","priyajeyah"); 
          String query1="insert into payment(pay_id,amount,date,car_no,sys_id) values(?,?,?,?,?)";
          PreparedStatement pst1=(PreparedStatement) conn.prepareStatement(query1);
          pst1.setInt(1,pay_id);
          pst1.setInt(2, amount);
          pst1.setString(3,payment_date);
          pst1.setString(4,cno);
          pst1.setInt(5, 1);
          pst1.executeUpdate();
          String query2="update slot set car_no=NULL where slot_id='"+sid+"'";
          String query3="update slot set timer_id=NULL where slot_id='"+sid+"'";
          PreparedStatement pst2=(PreparedStatement) conn.prepareStatement(query2);
          PreparedStatement pst3=(PreparedStatement) conn.prepareStatement(query3);
          //pst2.setInt(1,sid);
          pst2.executeUpdate();
          pst3.executeUpdate();
          //System.out.println("Updtaed sdfefef");
          String query4="delete from timer where timer_id='"+sid+"'";
          PreparedStatement pst4=(PreparedStatement)conn.prepareStatement(query4);
          pst4.execute();
          //System.out.println("delelewefejf");
          Sys s=new Sys();
      s.enterChoice();
          
          
      }
      catch(Exception e)
      {
          e.printStackTrace();
      }
  }
}
  /*public static void main(String[] args)
  {
      Payment p=new Payment();
      p.handlePayment();
  }*/