/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class SlotValidTest {
    SlotValid sv;
    public SlotValidTest() {
    }
    
    @Before
    public void setUp() {
        sv=new SlotValid();
    }
    
    @After
    public void tearDown() {
        sv=null;
    }

    @Test
    public void testvalidSlot() {
        int sid=8;
        int j;
        j=sv.validSlot(sid);
        assertEquals(1,j);
    }
    
}
