/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class SysTest {
    
    public SysTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of generatePin method, of class Sys.
     */
    @Test
    public void testGeneratePin() {
        System.out.println("generatePin");
        String cno = "";
        int sid=0;
        String hour="";
        Sys instance = new Sys();
        instance.generatePin(cno,sid,hour);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateReport method, of class Sys.
     */
    @Test
    public void testGenerateReport() {
        System.out.println("generateReport");
        Sys instance = new Sys();
        instance.generateReport();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of notifyDriver method, of class Sys.
     */
    @Test
    public void testNotifyDriver() {
        System.out.println("notifyDriver");
        String sec = "";
        String mail="";
        Sys instance = new Sys();
        instance.notifyDriver(sec,mail);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enterChoice method, of class Sys.
     */
    @Test
    public void testEnterChoice() {
        System.out.println("enterChoice");
        Sys instance = new Sys();
        instance.enterChoice();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
