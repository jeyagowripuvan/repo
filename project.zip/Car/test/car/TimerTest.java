/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class TimerTest {
    
    public TimerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of calculateTime method, of class Timer.
     */
    @Test
    public void testCalculateTime() {
        System.out.println("calculateTime");
        int sid = 0;
        String cno = "";
        Timer instance = new Timer();
        instance.calculateTime(sid, cno);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of startTimer method, of class Timer.
     */
    @Test
    public void testStartTimer() {
        System.out.println("startTimer");
        int sid = 0;
        String cno = "";
        Timer instance = new Timer();
        instance.startTimer(sid, cno);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of stopTimer method, of class Timer.
     */
    @Test
    public void testStopTimer() {
        System.out.println("stopTimer");
        int sid = 0;
        String cno = "";
        Timer instance = new Timer();
        instance.stopTimer(sid, cno);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
