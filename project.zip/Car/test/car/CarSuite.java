/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author HP
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({car.TimerTest.class, car.CarTest.class, car.SlotTest.class, car.SysTest.class, car.AdminTest.class, car.NotifyTest.class, car.MaskTest.class, car.DriverTest.class, car.PaymentTest.class})
public class CarSuite {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
