/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class DriverTest {
    
    public DriverTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of enterDetails method, of class Driver.
     */
    @Test
    public void testEnterDetails() {
        System.out.println("enterDetails");
        Driver instance = new Driver();
        String expResult = "";
        String result = instance.enterDetails();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enterSlot method, of class Driver.
     */
    @Test
    public void testEnterSlot() {
        System.out.println("enterSlot");
        Driver instance = new Driver();
        int expResult = 0;
        int result = instance.enterSlot();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enterPin method, of class Driver.
     */
    @Test
    public void testEnterPin() {
        System.out.println("enterPin");
        Driver instance = new Driver();
        instance.enterPin();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
