package com.example.demo.model;

public class OrderEvent {

	private String message;
	private OrderModel order;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public OrderModel getOrder() {
		return order;
	}
	public void setOrder(OrderModel order) {
		this.order = order;
	}
	@Override
	public String toString() {
		return "OrderEvent [message=" + message + ", order=" + order + "]";
	}
}
