package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.OrderEvent;
import com.example.demo.model.OrderModel;
import com.example.demo.service.OrderService;

@Controller
public class OrderController {

	@Autowired
	private OrderService orderService;

    @PostMapping("/placeorder")
    public ResponseEntity<String> publish(@RequestBody OrderModel order){
    	OrderEvent orderEvent= new OrderEvent();
    	orderEvent.setMessage("Order placed");
    	orderEvent.setOrder(order);
        orderService.sendMessage(orderEvent);
        return ResponseEntity.ok("Order message sent successfully");
    }
}
