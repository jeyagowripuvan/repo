package com.cognizant.surveyteam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveyTeamApplicationTests {

	@Test
	void contextLoads() {
	}

}
