package com.cognizant.rewardsteam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RewardsTeamApplicationTests {

	@Test
	void contextLoads() {
	}

}
