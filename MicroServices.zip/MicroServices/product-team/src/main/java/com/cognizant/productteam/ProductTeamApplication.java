package com.cognizant.productteam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class ProductTeamApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductTeamApplication.class, args);
	}

}
