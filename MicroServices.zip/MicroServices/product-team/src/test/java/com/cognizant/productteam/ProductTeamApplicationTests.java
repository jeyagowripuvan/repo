package com.cognizant.productteam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductTeamApplicationTests {

	@Test
	void contextLoads() {
	}

}
