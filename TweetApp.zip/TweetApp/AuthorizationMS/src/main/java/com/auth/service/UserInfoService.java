package com.auth.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.auth.model.AuthResponse;
import com.auth.model.UserInfo;

public interface UserInfoService extends UserDetailsService{

	public UserInfo login(@RequestBody UserInfo userLoginInfo);
	
	public AuthResponse getValidity(@RequestHeader String token);
	
	public UserInfo resetPassword(@RequestBody String loginId,@RequestBody String password,@RequestBody String newPassword);
	
	public UserInfo register(@RequestBody UserInfo userInfo);
	
	public UserInfo forgotPassword(@RequestBody String loginId, @RequestBody String newPassword);
	
	public List<UserInfo> getAllUsers();
	
	public List<UserInfo> searchAllByUserName(@RequestBody String userName);
}
