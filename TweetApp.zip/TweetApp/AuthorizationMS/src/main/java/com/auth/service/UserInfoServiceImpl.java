package com.auth.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.auth.controller.InvalidPasswordException;
import com.auth.controller.UnauthorizedException;
import com.auth.model.AuthResponse;
import com.auth.model.UserInfo;
import com.auth.repository.UserRepo;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UserInfoServiceImpl implements UserInfoService{
	@Autowired
	public UserRepo userRepo;
	@Autowired
	public JwtUtil jwtUtil;
	

	@Override
	public UserDetails loadUserByUsername(String id) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		Optional<UserInfo> user = userRepo.findById(id);
		if(user == null) {
			throw new UnauthorizedException("Wrong Username or Password");
		}
		UserInfo userInfo = user.get();
		 return new User(userInfo.getLoginId(),userInfo.getPassword(), new ArrayList<>());
	}
	
	@Override
	public UserInfo login(UserInfo userLoginInfo){
		final UserDetails userDetails = loadUserByUsername(userLoginInfo.getLoginId());
		String loginId = "";
		String generateToken = "";
		if (userDetails.getPassword().equals(userLoginInfo.getPassword())) {
			loginId = userLoginInfo.getLoginId();
			generateToken = jwtUtil.generateToken(userDetails);
			return new UserInfo(loginId, generateToken);
		} else {
			log.error("Unauthorized exception");
			throw new UnauthorizedException("Unauthorized");
		}
	}
	
	
	@Override
	public AuthResponse getValidity(String token) {
		AuthResponse res = new AuthResponse();
		if (jwtUtil.validateToken(token)) {
			res.setLoginId(jwtUtil.extractUsername(token));
			res.setValid(true);
			res.setName(userRepo.findById(jwtUtil.extractUsername(token)).get().getFirstName()+userRepo.findById(jwtUtil.extractUsername(token)).get().getLastName());
		} else {
			res.setValid(false);
			log.info("At Validity : ");
			log.error("Token Has Expired");
		}
		return res;
	}

	@Override
	public UserInfo resetPassword(String loginId, String password, String newPassword) {
		// TODO Auto-generated method stub
		Optional<UserInfo> user = userRepo.findById(loginId);
		if(user == null) {
			throw new UnauthorizedException("Wrong Username or Password");
		}
		UserInfo userInfo = user.get();
		if (userInfo.getPassword().equals(password)) {
			userInfo.setPassword(newPassword);
			userInfo.setConfirmPassword(newPassword);
			userRepo.save(userInfo);
			return userInfo;
		} else {
			log.error("Password reset failed");
			throw new InvalidPasswordException("Entered password is incorrect");
		}
	}

	@Override
	public UserInfo register(UserInfo userInfo) {
		// TODO Auto-generated method stub
		userRepo.save(userInfo);
		return userInfo;
	}

	@Override
	public UserInfo forgotPassword(String loginId, String newPassword) {
		// TODO Auto-generated method stub
		Optional<UserInfo> user = userRepo.findById(loginId);
		if(user == null) {
			throw new UnauthorizedException("Invalid Username");
		}
		else {
			UserInfo userInfo = user.get();
			userInfo.setPassword(newPassword);
			userInfo.setConfirmPassword(newPassword);
			userRepo.save(userInfo);
			return userInfo;
		}
	}

	@Override
	public List<UserInfo> getAllUsers() {
		// TODO Auto-generated method stub
		List<UserInfo> usersList = new ArrayList<UserInfo>();
		usersList = userRepo.findAll();
		return usersList;
	}

	@Override
	public List<UserInfo> searchAllByUserName(String userName) {
		// TODO Auto-generated method stub
		List<UserInfo> usersList = new ArrayList<UserInfo>();
		usersList = userRepo.findByFirstNameLikeOrderByLoginIdAsc(userName);
		return usersList;
	}

	

	
}
