package com.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootApplication
public class AuthorizationMsApplication {

	public static void main(String[] args) {
		log.info("AuthorizationMsApplication started");
		SpringApplication.run(AuthorizationMsApplication.class, args);
	}

}
