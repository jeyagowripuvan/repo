package com.auth.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class AuthResponseTest {

	AuthResponse auth = new AuthResponse();
	AuthResponse auth1 = new AuthResponse("admin", "admin", true);
	@Test
	void testLoginId() {
		auth.setLoginId("admin");
		assertEquals(auth.getLoginId(),"admin");
	}
	@Test
	void testName() {
		auth.setName("admin");
		assertEquals(auth.getName(), "admin");
	}
	@Test
	void testValid() {
		auth.setValid(true);
		assertEquals(auth.isValid(),true);
	}
	@Test
	void testToString() {
		assertTrue(auth1.toString().contains("admin"));
	}
}
