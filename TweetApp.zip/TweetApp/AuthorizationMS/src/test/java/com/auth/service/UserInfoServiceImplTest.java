package com.auth.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;

import com.auth.controller.InvalidPasswordException;
import com.auth.controller.UnauthorizedException;
import com.auth.model.AuthResponse;
import com.auth.model.UserInfo;
import com.auth.repository.UserRepo;

@SpringBootTest
class UserInfoServiceImplTest {
	@InjectMocks
	UserInfoServiceImpl userService;
	@Mock
	public UserRepo userRepo;
	@Mock
	public JwtUtil jwtUtil;
	
	@Test
	void loadUserByUsernameTest() {
		UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		Optional<UserInfo> data = Optional.of(user);
		when(userRepo.findById("admin")).thenReturn(data);
		UserDetails result = userService.loadUserByUsername("admin");
		assertEquals(user.getLoginId(),result.getUsername());
	}
	@Test
	void loadUserByUsernameFailedTest() {
		when(userRepo.findById("sample")).thenReturn(null);
		assertThrows(UnauthorizedException.class,()-> userService.loadUserByUsername("sample"));
	}
	@Test
	void loginTest() {
		UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		Optional<UserInfo> data = Optional.of(user);
		when(userRepo.findById("admin")).thenReturn(data);
		UserDetails value = userService.loadUserByUsername("admin");
		when(jwtUtil.generateToken(value)).thenReturn("token");
		UserInfo user1 = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		assertEquals(userService.login(user).getLoginId(),user1.getLoginId());
	}
	@Test
	void loginFailedTest() {
		UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		Optional<UserInfo> data = Optional.of(user);
		when(userRepo.findById("admin")).thenReturn(data);
		UserDetails value = userService.loadUserByUsername("admin");
		when(jwtUtil.generateToken(value)).thenReturn("token");
		UserInfo user1 = new UserInfo("admin", "admin", "admin", "admin", "pwd", "admin", 9876543210L);
		assertThrows(UnauthorizedException.class,()-> userService.login(user1));
	}
	@Test
	void testGetValidity()
	{
		 UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		  Optional<UserInfo> data = Optional.of(user);
		  when(jwtUtil.validateToken("token")).thenReturn(true);
		  when(jwtUtil.extractUsername("token")).thenReturn("admin");
		  when(userRepo.findById(jwtUtil.extractUsername("token"))).thenReturn(data);
		  AuthResponse auth = new AuthResponse("admin","adminadmin",true); 
		  assertEquals(userService.getValidity("token").getLoginId(),auth.getLoginId()); 
	}
	@Test
	void getValidityFailedTest()
	{
		 when(jwtUtil.validateToken("token")).thenReturn(false);
		 AuthResponse auth = new AuthResponse(null,null,false);
		 assertEquals(userService.getValidity("token").isValid(),auth.isValid()); 
	}
	@Test
	void resetPassword() {
		UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		Optional<UserInfo> data = Optional.of(user);
		when(userRepo.findById("admin")).thenReturn(data);
		assertEquals(userService.resetPassword("admin", "admin", "pwd").getLoginId(),user.getLoginId());
	}
	@Test
	void resetPasswordUnAuthorizedExceptionTest() {
		when(userRepo.findById("sample")).thenReturn(null);
		assertThrows(UnauthorizedException.class,()-> userService.resetPassword("sample", "admin", "admin"));
	}
	@Test
	void resetPasswordInvalidPasswordExceptionTest() {
		UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		Optional<UserInfo> data = Optional.of(user);
		when(userRepo.findById("admin")).thenReturn(data);
		assertThrows(InvalidPasswordException.class,()-> userService.resetPassword("admin", "pwd", "admin"));
	}
	@Test
	void registerTest() {
		UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		assertEquals(userService.register(user),user);
	}
	@Test
	void forgotPasswordTest() {
		UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		Optional<UserInfo> data = Optional.of(user);
		when(userRepo.findById("admin")).thenReturn(data);
		assertEquals(userService.forgotPassword("admin","pwd").getLoginId(), user.getLoginId());
	}
	@Test
	void forgotPasswordUnAuthorizedExceptionTest() {
		when(userRepo.findById("sample")).thenReturn(null);
		assertThrows(UnauthorizedException.class,()-> userService.forgotPassword("sample","pwd"));
	}
	@Test
	void getAllUsersTest() {
		List<UserInfo> usersList = new ArrayList<UserInfo>();
		when(userRepo.findAll()).thenReturn(usersList);
		assertEquals(userService.getAllUsers(), usersList);
	}
	@Test
	void searchAllByUserNameTest() {
		List<UserInfo> usersList = new ArrayList<UserInfo>();
		when(userRepo.findByFirstNameLikeOrderByLoginIdAsc("admin")).thenReturn(usersList);
		assertEquals(userService.searchAllByUserName("admin"), usersList);
	}
}
