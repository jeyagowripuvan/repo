package com.auth.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.MissingRequestHeaderException;

@SpringBootTest
class RestExceptionHandlerTest {

	@InjectMocks
	RestExceptionHandler restExceptionHandler;
	
	@Test
	void handleUnauthorizedExceptionsTest() {
		assertEquals(restExceptionHandler.handleUnauthorizedExceptions(new UnauthorizedException(null)).getStatusCodeValue(), 400);
	}
	@Test
	void handleInvalidPasswordExceptionsTest() {
		assertEquals(restExceptionHandler.handleInvalidPasswordExceptions(new InvalidPasswordException(null)).getStatusCodeValue(), 400);
	}
	@Test
	void handleMissingRequestHeaderExceptionTest() {
		assertEquals(restExceptionHandler.handleMissingRequestHeaderException(new MissingRequestHeaderException(null, null)).getStatusCodeValue(), 400);
	}

}
