package com.auth.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.auth.model.AuthResponse;
import com.auth.model.UserInfo;
import com.auth.service.UserInfoServiceImpl;

@SpringBootTest
class AuthControllerTest {

	@InjectMocks
	AuthController authController;
	@Mock
	public UserInfoServiceImpl userService;

	@Test
	void loginTest() {
		UserInfo userInfo = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		when(userService.login(userInfo)).thenReturn(userInfo);
		assertEquals(authController.login(userInfo), userInfo);

	}

	@Test
	void registerTest() {
		UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		when(userService.register(user)).thenReturn(user);
		assertEquals(authController.register(user), user);
	}

	@Test
	void getValidityTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(userService.getValidity("token")).thenReturn(auth);
		assertEquals(authController.getValidity("token"), auth);
	}

	@Test
	void resetPasswordTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(userService.getValidity("token")).thenReturn(auth);
		UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		when(userService.resetPassword("admin", "admin", "admin")).thenReturn(user);
		assertEquals(authController.resetPassword("token", user), user);

	}

	@Test
	void resetPasswordFailedTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(userService.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, () -> authController.resetPassword("token", null));
	}

	@Test
	void forgetPasswordTest() {
		UserInfo user = new UserInfo("admin", "admin", "admin", "admin", "newpwd", "admin", 9876543210L);
		when(userService.forgotPassword("admin", "newpwd")).thenReturn(user);
		assertEquals(authController.forgetPassword("admin", "newpwd"), user);

	}

	@Test
	void getAllUsersTest() {
		List<UserInfo> userList = new ArrayList<UserInfo>();
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(userService.getValidity("token")).thenReturn(auth);
		when(userService.getAllUsers()).thenReturn(userList);
		assertEquals(authController.getAllUsers("token"), userList);
	}
	@Test
	void getAllUsersFailedTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(userService.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, ()-> authController.getAllUsers("token"));
	}
	@Test
	void searchByUserNameTest() {
		List<UserInfo> userList = new ArrayList<UserInfo>();
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(userService.getValidity("token")).thenReturn(auth);
		when(userService.searchAllByUserName("admin")).thenReturn(userList);
		assertEquals(authController.searchByUserName("token", "admin"), userList);
	}
	@Test
	void searchByUserNameFailedTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(userService.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, ()-> authController.searchByUserName("token", "admin"));
	}
}
