package com.tweetApp.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.tweetApp.model.Comment;
import com.tweetApp.model.Tweet;
import com.tweetApp.model.UserInfo;
import com.tweetApp.service.TweetAppServiceImpl;

@SpringBootTest
class TweetAppControllerTest {
	@InjectMocks
	TweetAppController tweetAppController;
	@Mock
	public TweetAppServiceImpl tweetAppService;

	@Test
	void loginTest() {
		UserInfo userInfo = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		HttpSession session = null;
		when(tweetAppService.login(userInfo, session)).thenReturn("success");
		assertEquals(tweetAppController.login(userInfo, session), "success");
	}
	@Test
	void registerTest() {
		UserInfo userInfo = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		when(tweetAppService.register(userInfo)).thenReturn(userInfo);
		assertEquals(tweetAppController.register(userInfo),userInfo);
	}
	@Test
	void forgotPasswordTest() {
		UserInfo userInfo = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L);
		when(tweetAppService.forgotPassword("admin", "admin")).thenReturn(null);
		assertEquals(tweetAppController.forgotPassword("admin", userInfo), null);
	}
	@Test
	void getAllTweetsTest() {
		List<Tweet> tweetList = new ArrayList<Tweet>();
		HttpSession session = null;
		when(tweetAppService.getAllTweets(session)).thenReturn(tweetList);
		assertEquals(tweetAppController.getAllTweets(session),tweetList);
	}
	@Test
	void getAllUsersTest() {
		List<UserInfo> list = new ArrayList<UserInfo>();
		HttpSession session = null;
		when(tweetAppService.getAllUsers(session)).thenReturn(list);
		assertEquals(tweetAppController.getAllUsers(session),list);
	}
	@Test
	void searchByUserNameTest() {
		List<UserInfo> list = new ArrayList<UserInfo>();
		HttpSession session = null;
		when(tweetAppService.searchByUserName("admin", session)).thenReturn(list);
		assertEquals(tweetAppController.searchByUserName("admin", session), list);
	}
	@Test
	void getAllTweetsOfUserTest() {
		List<Tweet> tweetList = new ArrayList<Tweet>();
		HttpSession session = null;
		when(tweetAppService.getAllTweetsOfUser("admin", session)).thenReturn(tweetList);
		assertEquals(tweetAppController.getAllTweetsOfUser("admin", session), tweetList);
	}
    @Test
    void postTweetTest() {
    	List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		HttpSession session = null;
		when(tweetAppService.postTweet(tweet, session)).thenReturn(tweet);
		assertEquals(tweetAppController.postTweet("admin", tweet, session), tweet);
    }
    @Test
    void updateTweetTest() {
    	List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		HttpSession session = null;
		when(tweetAppService.updateTweet(1, "admin", session)).thenReturn(null);
		assertEquals(tweetAppController.updateTweet("admin", 1, tweet, session), null);
    }
    @Test
    void deleteTweetTest() {
    	HttpSession session = null;
    	when(tweetAppService.deleteTweet(1, session)).thenReturn("sample");
    	assertEquals(tweetAppController.deleteTweet("admin",1, session), "sample");
    }
    @Test
    void likeTweetTest() {
    	List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		HttpSession session = null;
		when(tweetAppService.likeTweet(1, 1, session)).thenReturn(tweet);
		assertEquals(tweetAppController.likeTweet("admin", 1, tweet, session), tweet);
    }
    @Test
    void replyTweetTest() {
    	Comment comment= new Comment( "sample", "time");
    	HttpSession session = null;
    	when(tweetAppService.replyTweet(comment, 1, session)).thenReturn(comment);
    	assertEquals(tweetAppController.replyTweet("admin",1, comment, session), comment);
    }
}
