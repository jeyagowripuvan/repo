package com.tweetApp.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class UserInfoTest {

	UserInfo user = new UserInfo();
	UserInfo user1 = new UserInfo("admin", "token");
	UserInfo userInfo = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L,"admin","admin");

	@Test
	void testLoginId() {
		user.setLoginId("admin");
		assertEquals(user.getLoginId(), "admin");
	}

	@Test
	void testFirstName() {
		user.setFirstName("admin");
		assertEquals(user.getFirstName(), "admin");
	}

	@Test
	void testLastName() {
		user.setLastName("admin");
		assertEquals(user.getLastName(), "admin");
	}

	@Test
	void testEmail() {
		user.setEmail("admin");
		assertEquals(user.getEmail(), "admin");
	}

	@Test
	void testPassword() {
		user.setPassword("admin");
		assertEquals(user.getPassword(), "admin");
	}

	@Test
	void testConfirmPassword() {
		user.setConfirmPassword("admin");
		assertEquals(user.getConfirmPassword(), "admin");
	}

	@Test
	void testContactNumber() {
		user.setContactNumber(9876543210L);
		assertEquals(user.getContactNumber(), 9876543210L);
	}

	@Test
	void testAuthToken() {
		user.setAuthToken("token");
		assertEquals(user.getAuthToken(), "token");
	}

	@Test
	void testNewPassword() {
		user.setNewPassword("admin");
		assertEquals(user.getNewPassword(), "admin");
	}
	@Test
	void testToString() {
		assertTrue(userInfo.toString().contains("admin"));
	}
}
