package com.tweetApp.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.net.ConnectException;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.bind.MissingRequestHeaderException;


@SpringBootTest
class RestExceptionHandlerTest {

	@InjectMocks
	RestExceptionHandler restExceptionHandler;
	
	@Test
	void handleUnauthorizedExceptionsTest() {
		assertEquals(restExceptionHandler.handleUnauthorizedExceptions(new UnauthorizedException(null)).getStatusCodeValue(), 400);
	}
	@Test
	void handleTweetNotFoundExceptionsTest() {
		assertEquals(restExceptionHandler.handleTweetNotFoundExceptions(new TweetNotFoundException(null)).getStatusCodeValue(), 400);
	}
	@Test
	void handleMissingRequestHeaderExceptionTest() {
		assertEquals(restExceptionHandler.handleMissingRequestHeaderException(new MissingRequestHeaderException(null,null)).getStatusCodeValue(), 400);
	}
	@Test
	void handleConnectExceptionsTest() {
		assertEquals(restExceptionHandler.handleConnectExceptions(new ConnectException()).getStatusCodeValue(), 400);
	}
	@Test
	void handleUserNotFoundExceptionsTest() {
		assertEquals(restExceptionHandler.handleUserNotFoundExceptions(new UserNotFoundException(null)).getStatusCodeValue(), 400);
	}
}
