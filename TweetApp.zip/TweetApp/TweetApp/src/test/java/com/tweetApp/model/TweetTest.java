package com.tweetApp.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TweetTest {

	Tweet tweet1= new Tweet();
	List<Comment> commentList = new ArrayList<Comment>();
	Tweet tweet2 = new Tweet(1, "sample", 1, "sample", "admin", commentList);
	@Test
	void testTweetId() {
		tweet1.setTweetId(1);
		assertEquals(tweet1.getTweetId(), 1);
	}
	@Test
	 void testTweetDescription() {
		tweet1.setTweetDescription("sample");
		assertEquals(tweet1.getTweetDescription(), "sample");
	}
	@Test
	void testLikesCount() {
		tweet1.setLikesCount(1);
		assertEquals(tweet1.getLikesCount(), 1);
	}
	@Test
	void testTimeStamp() {
		tweet1.setTimeStamp("time");
		assertEquals(tweet1.getTimeStamp(), "time");
	}
	@Test
	void testUserId() {
		tweet1.setUserId("admin");
		assertEquals(tweet1.getUserId(), "admin");
	}
	@Test
	void testToString() {
		assertTrue(tweet2.toString().contains("admin"));
	}
	@Test
	void testSetCommentsList() {
		List<Comment> commentsList = new ArrayList<Comment>();
		tweet1.setCommentsList(commentsList);
		assertEquals(tweet1.getCommentsList(), commentsList);
	}
}
