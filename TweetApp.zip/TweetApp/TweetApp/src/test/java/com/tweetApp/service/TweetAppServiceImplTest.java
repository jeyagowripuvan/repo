package com.tweetApp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.tweetApp.client.AuthClient;
import com.tweetApp.client.TweetClient;
import com.tweetApp.model.Tweet;
import com.tweetApp.model.UserInfo;

@SpringBootTest
class TweetAppServiceImplTest {
	@InjectMocks
	TweetAppServiceImpl tweetAppService;
	@Mock
	public AuthClient authClient;
	@Mock
	public TweetClient tweetClient;
	@Mock
    RabbitMQSender rabbitMQSender;
	
	@Test
	void registerTest() {
		UserInfo userInfo = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L,"token","admin");
		when(authClient.register(userInfo)).thenReturn(userInfo);
		assertEquals(tweetAppService.register(userInfo), userInfo);
	}
	@Test
	void forgotPasswordTest() {
		UserInfo userInfo = new UserInfo("admin", "admin", "admin", "admin", "admin", "admin", 9876543210L,"token","admin");
		when(authClient.forgetPassword("admin","admin")).thenReturn(userInfo);
		assertEquals(tweetAppService.forgotPassword("admin", "admin"), userInfo);
	}

}
