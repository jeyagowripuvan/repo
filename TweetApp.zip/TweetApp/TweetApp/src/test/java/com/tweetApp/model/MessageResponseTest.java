package com.tweetApp.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

class MessageResponseTest {

	MessageResponse messageResponse = new MessageResponse();
	HttpStatus status;
	Date timeStamp;

	MessageResponse message1 = new MessageResponse("response", status);

	MessageResponse message2 = new MessageResponse(timeStamp,"response", status);

	@Test
	public void testMessage() {
		messageResponse.setMessage("message");
		messageResponse.setStatus(status);
		messageResponse.setTimeStamp(new Date());
		messageResponse.getTimeStamp();
		assertEquals(messageResponse.getMessage(), "message");
		assertEquals(messageResponse.getStatus(), status);
	}

	@Test
	public void testCons() {
		assertEquals(message1.getMessage(), "response");
	}

}
