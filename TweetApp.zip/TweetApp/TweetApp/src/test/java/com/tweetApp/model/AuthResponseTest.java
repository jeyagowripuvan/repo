package com.tweetApp.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class AuthResponseTest {

	AuthResponse auth = new AuthResponse();
	AuthResponse auth1 = new AuthResponse("admin", "admin", true);
	@Test
	void testLoginId() {
		auth.setUid("admin");
		assertEquals(auth.getUid(),"admin");
	}
	@Test
	void testName() {
		auth.setName("admin");
		assertEquals(auth.getName(), "admin");
	}
	@Test
	void testValid() {
		auth.setValid(true);
		assertEquals(auth.isValid(),true);
	}
	@Test
	void testToString() {
		assertTrue(auth1.toString().contains("admin"));
	}


}
