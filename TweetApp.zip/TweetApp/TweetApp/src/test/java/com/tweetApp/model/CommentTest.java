package com.tweetApp.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CommentTest {

	Comment comment1= new Comment();
	Comment comment2= new Comment("sample", "time");
	@Test
	void testCommentDescription() {
		comment1.setCommentDescription("sample");
		assertEquals(comment1.getCommentDescription(), "sample");
	}
	@Test
	void testTimeStamp() {
		comment1.setTimeStamp("time");
		assertEquals(comment1.getTimeStamp(), "time");
	}
	@Test
	void testToString() {
		assertTrue(comment2.toString().contains("sample"));
	}
}
