package com.tweetApp.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.tweetApp.model.Comment;
import com.tweetApp.model.Tweet;

@FeignClient(url = "${tweet.feng.client}", name = "${tweet.feng.name}")
public interface TweetClient {

	@GetMapping("/getTweet/{tweetId}")
	public Tweet getTweet(@PathVariable("tweetId") int tweetId, @RequestHeader("Authorization") String token);

	@GetMapping("/getAllTweet")
	public List<Tweet> displayAllTweet(@RequestHeader("Authorization") String token);

	@GetMapping("/getAllTweetsOfUser/{userId}")
	public List<Tweet> getAllTweetsOfUser(@PathVariable("userId") String userId,
			@RequestHeader("Authorization") String token);

	@PostMapping("/postTweet")
	public Tweet postTweet(@RequestHeader("Authorization") String token, @RequestBody Tweet tweet);

	@PutMapping("/updateTweetInfo/{tweetId}/{description}")
	public void updateTweetDescription(@PathVariable("tweetId") int tweetId,
			@RequestHeader("Authorization") String token, @PathVariable("description") String description);

	@PutMapping("/likeTweet/{tweetId}/{count}")
	public void updateLikeCount(@PathVariable("tweetId") int tweetId, @PathVariable("count") int count,
			@RequestHeader("Authorization") String token);

	@DeleteMapping("/deleteTweet/{tweetId}")
	public void deleteTweet(@RequestHeader("Authorization") String token, @PathVariable("tweetId") int tweetId);

	@PostMapping("/replyTweet/{tweetId}")
	public void addComment(@PathVariable("tweetId") int tweetId, @RequestHeader("Authorization") String token,
			@RequestBody Comment comment);

	@GetMapping("/getAllReply/{tweetId}")
	public List<Comment> getAllReplyOfTweet(@PathVariable("tweetId") int tweetId,
			@RequestHeader("Authorization") String token);
}
