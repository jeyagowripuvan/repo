package com.tweetApp.model;


import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Tweet {
	
	private int tweetId;
	private String tweetDescription;
	private int likesCount;
	private String timeStamp;
	private String userId;
	
	private List<Comment> commentsList = new ArrayList<Comment>();
}

