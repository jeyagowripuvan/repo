package com.tweetApp.service;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import com.tweetApp.model.Tweet;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Component
@RabbitListener(queues = "rabbitmq.queue", id = "listener")
public class RabbitMQReceiver {
    @RabbitHandler
    public void receiver(Tweet tweet) {
        log.info("Tweet listener invoked : ");
    }
}