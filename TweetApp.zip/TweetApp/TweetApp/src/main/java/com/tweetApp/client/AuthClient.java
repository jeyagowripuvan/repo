package com.tweetApp.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.tweetApp.model.AuthResponse;
import com.tweetApp.model.UserInfo;

@FeignClient(url = "${auth.feng.client}", name = "${auth.feng.name}")
public interface AuthClient {

	/**
	 * Communicates with Authorization Microservice by enabling feign client
	 * 
	 * @param token JWT token for validation
	 * @return AuthResponse object(user Id,user name,validity of token)
	 */
	@PostMapping("/validate")
	public AuthResponse getValidity(@RequestHeader("Authorization") String token);
	@PostMapping("/login")
	public UserInfo login(@RequestBody UserInfo userLoginInfo);
	@PostMapping("/register")
	public UserInfo register(@RequestBody UserInfo userInfo);
	@PostMapping("/forgetPassword/{loginId}")
	public UserInfo forgetPassword(@PathVariable("loginId") String loginId, @RequestParam("newPassword") String newPassword);
	@GetMapping("/getAll")
	public List<UserInfo> getAllUsers(@RequestHeader("Authorization") String token);
	@GetMapping("/searchByName/{userName}")
	public List<UserInfo> searchByUserName(@RequestHeader("Authorization") String token,@PathVariable("userName") String userName);
}
