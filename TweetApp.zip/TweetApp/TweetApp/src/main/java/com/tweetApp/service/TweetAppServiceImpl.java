package com.tweetApp.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetApp.client.AuthClient;
import com.tweetApp.client.TweetClient;
import com.tweetApp.exception.UnauthorizedException;
import com.tweetApp.model.Comment;
import com.tweetApp.model.Tweet;
import com.tweetApp.model.UserInfo;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TweetAppServiceImpl implements TweetAppService {
	@Autowired
	public AuthClient authClient;
	@Autowired
	public TweetClient tweetClient;
	@Autowired
    RabbitMQSender rabbitMQSender;

	@Override
	public String login(UserInfo userInfo, HttpSession session) throws UnauthorizedException, FeignException {
		// TODO Auto-generated method stub
		UserInfo user = null;
		user = authClient.login(userInfo);

		session.setAttribute("token", "Bearer " + user.getAuthToken());
		session.setAttribute("id", user.getLoginId());
		log.info("login using given user details");
		return "success";
	}

	@Override
	public UserInfo register(UserInfo userInfo) throws FeignException {
		// TODO Auto-generated method stub
		log.info("adding given user details");
		UserInfo user = authClient.register(userInfo);
		return user;
	}

	@Override
	public UserInfo forgotPassword(String loginId, String newPassword) {
		// TODO Auto-generated method stub
		log.info("updating password of given user details");
		UserInfo user = authClient.forgetPassword(loginId, newPassword);
		return user;
	}

	@Override
	public List<Tweet> getAllTweets(HttpSession session) {
		// TODO Auto-generated method stub
		String token = (String) session.getAttribute("token");
		session.getAttribute("id");
		log.info("retrieving list of all tweets");
		List<Tweet> tweetsList = tweetClient.displayAllTweet(token);
		return tweetsList;
	}

	@Override
	public List<UserInfo> getAllUsers(HttpSession session) {
		// TODO Auto-generated method stub
		String token = (String) session.getAttribute("token");
		session.getAttribute("id");
		List<UserInfo> usersList = authClient.getAllUsers(token);
		return usersList;
	}

	@Override
	public List<UserInfo> searchByUserName(String userName, HttpSession session) {
		// TODO Auto-generated method stub
		String token = (String) session.getAttribute("token");
		session.getAttribute("id");
		List<UserInfo> usersList = authClient.searchByUserName(token, userName);
		return usersList;
	}

	@Override
	public List<Tweet> getAllTweetsOfUser(String userId, HttpSession session) {
		// TODO Auto-generated method stub
		String token = (String) session.getAttribute("token");
		session.getAttribute("id");
		List<Tweet> tweetsList = tweetClient.getAllTweetsOfUser(userId, token);
		return tweetsList;
	}

	@Override
	public Tweet postTweet(Tweet tweet, HttpSession session) {
		// TODO Auto-generated method stub
		String token = (String) session.getAttribute("token");
		String id = (String) session.getAttribute("id");
		tweet.setUserId(id);
		Tweet tweetObj = tweetClient.postTweet(token, tweet);
		rabbitMQSender.send(tweetObj);
		return tweetObj;
	}

	@Override
	public Tweet updateTweet(int tweetId, String tweetDescription, HttpSession session) {
		// TODO Auto-generated method stub
		String token = (String) session.getAttribute("token");
		session.getAttribute("id");
		tweetClient.updateTweetDescription(tweetId, token, tweetDescription);
		return tweetClient.getTweet(tweetId, token);
	}

	@Override
	public String deleteTweet(int tweetId, HttpSession session) {
		// TODO Auto-generated method stub
		String token = (String) session.getAttribute("token");
		session.getAttribute("id");
		tweetClient.deleteTweet(token, tweetId);
		return "success";
	}

	@Override
	public Tweet likeTweet(int tweetId, int count, HttpSession session) {
		// TODO Auto-generated method stub
		String token = (String) session.getAttribute("token");
		session.getAttribute("id");
		tweetClient.updateLikeCount(tweetId, count, token);
		return tweetClient.getTweet(tweetId, token);
	}

	@Override
	public Comment replyTweet(Comment comment, int tweetId, HttpSession session) {
		// TODO Auto-generated method stub
		String token = (String) session.getAttribute("token");
		session.getAttribute("id");
		tweetClient.addComment(tweetId, token, comment);
		return comment;
	}

}
