package com.tweetApp.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.tweetApp.model.Comment;
import com.tweetApp.model.Tweet;
import com.tweetApp.model.UserInfo;

public interface TweetAppService {

	public String login(UserInfo userInfo, HttpSession session);
	
	public UserInfo register(UserInfo userInfo);
	
	public UserInfo forgotPassword(String loginId, String newPassword);
	
	public List<Tweet> getAllTweets(HttpSession session);
	
	public List<UserInfo> getAllUsers(HttpSession session);
	
	public List<UserInfo> searchByUserName(String userName, HttpSession session);
	
	public List<Tweet> getAllTweetsOfUser(String userId, HttpSession session);
	
	public Tweet postTweet(Tweet tweet, HttpSession session);
	
	public Tweet updateTweet(int tweetId, String tweetDescription, HttpSession session);
	
	public String deleteTweet(int tweetId, HttpSession session);
	
	public Tweet likeTweet(int tweetId,int count, HttpSession session);
	
	public Comment replyTweet(Comment comment, int tweetId, HttpSession session);
	
	
}
