package com.tweetApp.exception;

import java.net.ConnectException;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.tweetApp.model.MessageResponse;

import feign.FeignException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class RestExceptionHandler {

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(TweetNotFoundException.class)
	public ResponseEntity<?> handleTweetNotFoundExceptions(TweetNotFoundException ex) {
		String errorMessage= ex.getMessage();
		log.error(errorMessage);
		return ResponseEntity.badRequest().body(new MessageResponse(ex.getMessage(), HttpStatus.NOT_FOUND));
	}

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<?> handleUserNotFoundExceptions(UserNotFoundException ex) {
		String errorMessage= ex.getMessage();
		log.error(errorMessage);
		return ResponseEntity.badRequest().body(new MessageResponse(ex.getMessage(), HttpStatus.NOT_FOUND));
	}

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(UnauthorizedException.class)
	public ResponseEntity<?> handleUnauthorizedExceptions(UnauthorizedException ex) {
		String errorMessage= ex.getMessage();
		log.error(errorMessage);
		return ResponseEntity.badRequest().body(new MessageResponse(ex.getMessage(), HttpStatus.UNAUTHORIZED));
	}

	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(FeignException.InternalServerError.class)
	public ResponseEntity<?> handleFeignInternalServerError(FeignException ex) {
		String[] split = ex.getMessage().split("trace")[1].split(",");

		String errorMessage = split[0].substring(33, split[0].length() - 1);
		if (errorMessage.contains("No value present")) {
			return ResponseEntity.badRequest()
					.body(new MessageResponse("Invalid Username or Password", HttpStatus.INTERNAL_SERVER_ERROR));
		}
		return ResponseEntity.badRequest()
				.body(new MessageResponse("Service down.Please,try again later...", HttpStatus.INTERNAL_SERVER_ERROR));
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(FeignException.BadRequest.class)
	public ResponseEntity<?> handleFeignBadRequestExceptions(FeignException ex) {

		if (ex.getMessage().contains("trace")) {
			if (ex.getMessage().split("trace")[1].contains("MissingRequestHeaderException")) {
				return ResponseEntity.badRequest()
						.body(new MessageResponse("Service down.Please,try again later...", HttpStatus.BAD_REQUEST));
			}
		}
		String[] split = ex.getMessage().split("message")[1].split(",");

		String errorMessage = split[0].substring(3, split[0].length() - 1);
		log.info(errorMessage);

		if (errorMessage.contains("Authorisation required\"}") || errorMessage.contains("Service is down\"}")) {
			return ResponseEntity.badRequest().body(new MessageResponse("Session Expired...", HttpStatus.BAD_REQUEST));
		} else if (errorMessage.contains("Unauthorized request. Login again...")) {
			return ResponseEntity.badRequest()
					.body(new MessageResponse("Invalid Username or Password", HttpStatus.BAD_REQUEST));
		} else if (errorMessage.contains("Required Bearer token")) {
			return ResponseEntity.badRequest().body(new MessageResponse("Session Expired...", HttpStatus.BAD_REQUEST));
		}
		return ResponseEntity.badRequest().body(new MessageResponse(errorMessage, HttpStatus.BAD_REQUEST));
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(ConnectException.class)
	public ResponseEntity<?> handleConnectExceptions(ConnectException ex) {

		log.error("Client service down");
		return ResponseEntity.badRequest()
				.body(new MessageResponse("Service down.Please,try again later...", HttpStatus.BAD_REQUEST));
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MissingRequestHeaderException.class)
	public ResponseEntity<?> handleMissingRequestHeaderException(MissingRequestHeaderException ex) {

		log.error("Required Bearer token");
		return ResponseEntity.badRequest().body(new MessageResponse("Required Bearer token", HttpStatus.UNAUTHORIZED));
	}
}
