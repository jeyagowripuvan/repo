package com.tweetApp.model;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class UserInfo {

		private String loginId;
		private String firstName;
		private String lastName;
		private String email;
		private String password;
		private String confirmPassword;
		private long contactNumber;
		private String authToken;
		private String newPassword;
	
		public UserInfo(String loginId, String token) {
			this.authToken= token;
			this.loginId = loginId;
		}

		public UserInfo(String loginId, String firstName, String lastName, String email, String password,
				String confirmPassword, long contactNumber) {
			super();
			this.loginId = loginId;
			this.firstName = firstName;
			this.lastName = lastName;
			this.email = email;
			this.password = password;
			this.confirmPassword = confirmPassword;
			this.contactNumber = contactNumber;
		}

}
