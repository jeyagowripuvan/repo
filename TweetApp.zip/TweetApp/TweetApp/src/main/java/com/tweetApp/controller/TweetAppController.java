package com.tweetApp.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tweetApp.model.Comment;
import com.tweetApp.model.Tweet;
import com.tweetApp.model.UserInfo;
import com.tweetApp.service.TweetAppServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TweetAppController {
	@Autowired
	public TweetAppServiceImpl tweetAppService;

	@PostMapping("/login")
	public String login(@RequestBody UserInfo userInfo, HttpSession session) {
		log.info("login using given user details");
		return tweetAppService.login(userInfo, session);
	}

	@PostMapping("/register")
	public UserInfo register(@RequestBody UserInfo userInfo) {
		log.info("adding given user details");
		return tweetAppService.register(userInfo);
	}

	@PostMapping("/{loginId}/forgot")
	public UserInfo forgotPassword(@PathVariable("loginId") String loginId, @RequestBody UserInfo userInfo) {
		log.info("updating password of given user details");
		return tweetAppService.forgotPassword(loginId, userInfo.getNewPassword());
	}

	@GetMapping("/all")
	public List<Tweet> getAllTweets(HttpSession session) {
		log.info("retrieving list of all tweets");
		return tweetAppService.getAllTweets(session);
	}

	@GetMapping("/users/all")
	public List<UserInfo> getAllUsers(HttpSession session) {
		log.info("retrieving list of all users details");
		return tweetAppService.getAllUsers(session);
	}

	@GetMapping("/user/search/{userName}")
	public List<UserInfo> searchByUserName(@PathVariable("userName") String userName, HttpSession session) {
		log.info("retrieving list of user details of given user name");
		return tweetAppService.searchByUserName(userName, session);
	}

	@GetMapping("/{loginId}")
	public List<Tweet> getAllTweetsOfUser(@PathVariable("loginId") String loginId, HttpSession session) {
		log.info("retrieving list of all tweets of given user Id");
		return tweetAppService.getAllTweetsOfUser(loginId, session);
	}

	@PostMapping("/{loginId}/add")
	public Tweet postTweet(@PathVariable("loginId") String loginId, @RequestBody Tweet tweet, HttpSession session) {
		log.info("adding tweet details");
		return tweetAppService.postTweet(tweet, session);
	}

	@PutMapping("/{loginId}/update/{tweetId}")
	public Tweet updateTweet(@PathVariable("loginId") String loginId, @PathVariable("tweetId") int tweetId,
			@RequestBody Tweet tweet, HttpSession session) {
		log.info("updating tweet with given tweet details");
		return tweetAppService.updateTweet(tweetId, tweet.getTweetDescription(), session);
	}

	@DeleteMapping("/{loginId}/delete/{tweetId}")
	public String deleteTweet(@PathVariable("loginId") String loginId, @PathVariable("tweetId") int tweetId,
			HttpSession session) {
		log.info("Removing tweet details of given tweet Id");
		return tweetAppService.deleteTweet(tweetId, session);
	}

	@PutMapping("/{loginId}/like/{tweetId}")
	public Tweet likeTweet(@PathVariable("loginId") String loginId, @PathVariable("tweetId") int tweetId,
			@RequestBody Tweet tweet, HttpSession session) {
		log.info("Updating likes count number of given tweet Id");
		return tweetAppService.likeTweet(tweetId, tweet.getLikesCount(), session);
	}

	@PostMapping("/{loginId}/reply/{tweetId}")
	public Comment replyTweet(@PathVariable("loginId") String loginId, @PathVariable("tweetId") int tweetId,
			@RequestBody Comment comment, HttpSession session) {
		log.info("adding comment to given tweet Id");
		return tweetAppService.replyTweet(comment, tweetId, session);
	}

}
