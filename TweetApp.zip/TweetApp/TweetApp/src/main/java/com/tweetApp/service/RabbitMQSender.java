package com.tweetApp.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetApp.model.Tweet;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class RabbitMQSender {
    @Autowired
    private AmqpTemplate rabbitTemplate;
    @Autowired
    private Queue queue;
    //private static Logger logger = LogManager.getLogger(RabbitMQSender.class.toString());
    public void send(Tweet tweet) {
    	log.info("Sending Message to the Queue");
        rabbitTemplate.convertAndSend(queue.getName(), tweet);
        
    }
}
