package com.tweet.model;


import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Document(collection="tweetInfo")
public class Tweet {
	
	@Id
	private int tweetId;
	private String tweetDescription;
	private int likesCount;
	private String timeStamp;
	private String userId;
	
//	@JsonIgnore
//	@DocumentReference
	private List<Comment> commentsList = new ArrayList<Comment>();
}

