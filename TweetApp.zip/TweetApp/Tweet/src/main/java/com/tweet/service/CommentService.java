package com.tweet.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestHeader;

import com.tweet.model.AuthResponse;
import com.tweet.model.Comment;

public interface CommentService{
		
	public void addComment(int tweetId, Comment comment);
	
	public List<Comment> getAllCommentsOfTweet (int tweetId);
}
