package com.tweet.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.tweet.model.AuthResponse;
/**
 * @author Thripura
 * @project TweetApplication
 */
@FeignClient(url = "${auth.feng.client}", name = "${auth.feng.name}")
public interface AuthClient {

	/**
	 * Communicates with Authorization Microservice by enabling feign client
	 * 
	 * @param token JWT token for validation
	 * @return AuthResponse object(user Id,user name,validity of token)
	 */
	@PostMapping("/validate")
	public AuthResponse getValidity(@RequestHeader("Authorization") String token);
}
