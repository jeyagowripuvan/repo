package com.tweet.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
//@Document(collection="commentInfo")
public class Comment {
//	@Id
//	private int commentId;
	private String commentDescription;
	private String timeStamp;
	
//	@JsonIgnore
//	@DocumentReference(lazy=true)
//	private Tweet tweet;
}
