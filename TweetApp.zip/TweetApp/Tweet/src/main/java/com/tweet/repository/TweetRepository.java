package com.tweet.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweet.model.Comment;
import com.tweet.model.Tweet;

public interface TweetRepository extends MongoRepository<Tweet, Integer> {
	
	/**
	 * @param tweetId Id to get Tweet
	 * @return {@code true} if valid id 
	 */
	boolean existsByTweetId(int tweetId);
	/**
	 * @param userId Id 
	 * @return {@code true} if valid id 
	 */
	boolean existsByUserId(String userId);
	/**
	 * @param userId Id to get all tweets of that user
	 * @return list of tweets
	 */
	List<Tweet> findAllByUserId(String userId);
	/**
	 * @param tweetId Id to get all comments of that tweet
	 * @return list of comments of given tweet id
	 */
	List<Comment> findAllCommentsListByTweetId(int tweetId);

}
