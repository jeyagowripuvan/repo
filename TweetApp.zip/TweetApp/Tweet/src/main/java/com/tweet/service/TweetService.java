package com.tweet.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestHeader;

import com.tweet.model.AuthResponse;
import com.tweet.model.Tweet;

public interface TweetService {
		
	public List<Tweet> getAllTweets();
	
	public Tweet getTweet(int tweetId);
	
	public List<Tweet> getAllTweetsOfUser(String userId);
	
	public Tweet addTweet(Tweet tweetInfo);
	
	public void updateTweetDescription(String tweetDescription, int tweetId);
	
	public void updateTweetLikesCount(int count, int tweetId);
	
	public void deleteTweet(int tweetId);

}
