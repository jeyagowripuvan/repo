package com.tweet.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweet.exception.TweetNotFoundException;
import com.tweet.exception.UserNotFoundException;
import com.tweet.model.Tweet;
import com.tweet.repository.TweetRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TweetServiceImpl implements TweetService {
	@Autowired
	public TweetRepository tweetRepository;
	
		
	@Override
	public Tweet getTweet(int tweetId) {
		// TODO Auto-generated method stub
		if(!tweetRepository.existsByTweetId(tweetId)){
			throw new TweetNotFoundException("Tweet Not Found");
		}
		log.info("Retrieving tweet details of given tweet Id");
		Optional<Tweet> tweet = tweetRepository.findById(tweetId);
		return tweet.get();
	}

	@Override
	public List<Tweet> getAllTweetsOfUser(String userId) {
		// TODO Auto-generated method stub
		if(!tweetRepository.existsByUserId(userId)){
			throw new UserNotFoundException("User Not Found");
		}
		log.info("Retrieving list of all tweets details of given user Id");
		List<Tweet> userTweetsList = tweetRepository.findAllByUserId(userId);
		return userTweetsList;
	}
	
	@Override
	public List<Tweet> getAllTweets() {
		// TODO Auto-generated method stub
		log.info("Retrieving list of all tweets details");
		List<Tweet> tweetsList = tweetRepository.findAll();
		return tweetsList;
	}
	
	@Override
	public void updateTweetDescription(String tweetDescription, int tweetId) {
		// TODO Auto-generated method stub
		if(!tweetRepository.existsByTweetId(tweetId)){
			throw new TweetNotFoundException("Tweet Not Found");
		}
		Tweet tweet = tweetRepository.findById(tweetId).get();
		log.info("Updating tweet description of given tweet Id");
		tweet.setTweetDescription(tweetDescription);
		tweetRepository.save(tweet);
	}

	@Override
	public void updateTweetLikesCount(int count, int tweetId) {
		// TODO Auto-generated method stub
		if(!tweetRepository.existsByTweetId(tweetId)){
			throw new TweetNotFoundException("Tweet Not Found");
		}
		Tweet tweet = tweetRepository.findById(tweetId).get();
		log.info("Updating likes count number of given tweet Id");
		tweet.setLikesCount(tweet.getLikesCount()+count);
		tweetRepository.save(tweet);
	}

	@Override
	public Tweet addTweet(Tweet tweetInfo) {
		// TODO Auto-generated method stub
		log.info("Adding given tweet details");
		tweetRepository.save(tweetInfo);
		return tweetInfo;
	}

	@Override
	public void deleteTweet(int tweetId) {
		// TODO Auto-generated method stub
		if(!tweetRepository.existsByTweetId(tweetId)){
			throw new TweetNotFoundException("Tweet Not Found");
		}
		log.info("Removing given tweet of given tweet Id");
		tweetRepository.deleteById(tweetId);
	}


}
