package com.tweet.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.tweet.client.AuthClient;
import com.tweet.exception.UnauthorizedException;
import com.tweet.model.Comment;
import com.tweet.model.Tweet;
import com.tweet.service.CommentServiceImpl;
import com.tweet.service.TweetServiceImpl;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Thripura
 * @project TweetApplication
 */
@Slf4j
@RestController
public class TweetController {
	@Autowired
	public TweetServiceImpl tweetService;
	@Autowired
	public CommentServiceImpl commentService;
	@Autowired
	public AuthClient authClient;
	@PostMapping("/postTweet")
	public Tweet postTweet(@RequestHeader("Authorization") String token, @RequestBody Tweet tweet) {
		
		if (authClient.getValidity(token).isValid()) {
			log.info("adding tweet details");
			return tweetService.addTweet(tweet);
		}
		else {
			throw new UnauthorizedException("Session Expired");
		}
	}
	@GetMapping("/getTweet/{tweetId}")
	public Tweet getTweet(@PathVariable("tweetId") int tweetId, @RequestHeader("Authorization") String token) {
		if (authClient.getValidity(token).isValid()) {
			log.info("Retrieving tweet details");
			return tweetService.getTweet(tweetId);}
		else {
			throw new UnauthorizedException("Session Expired");
		}
	}
	@GetMapping("/getAllTweetsOfUser/{userId}")
	public List<Tweet> getAllTweetsOfUser (@PathVariable("userId") String userId, @RequestHeader("Authorization") String token) {
		if (authClient.getValidity(token).isValid()) {
			log.info("retrieving tweet details of given user");
			return tweetService.getAllTweetsOfUser(userId);}
		else {
			throw new UnauthorizedException("Session Expired");
		}
	}
	@PutMapping("/updateTweetInfo/{tweetId}/{description}")
	public void updateTweetDescription(@PathVariable("tweetId") int tweetId,@RequestHeader("Authorization") String token, @PathVariable("description") String description) {
		if (authClient.getValidity(token).isValid()) {
			log.info("updating tweet description of given tweet");
			tweetService.updateTweetDescription(description, tweetId);}
		else {
			throw new UnauthorizedException("Session Expired");
		}
	}
	@PutMapping("/likeTweet/{tweetId}/{count}")
	public void updateLikeCount( @PathVariable("tweetId") int tweetId,@PathVariable("count") int count, @RequestHeader("Authorization") String token) {
		if (authClient.getValidity(token).isValid()) {
			log.info("updating tweet likes count");
			tweetService.updateTweetLikesCount(count, tweetId);}
		else {
			throw new UnauthorizedException("Session Expired");
		}
	}
	@DeleteMapping("/deleteTweet/{tweetId}")
	public void deleteTweet(@RequestHeader("Authorization") String token, @PathVariable("tweetId") int tweetId) {
		if (authClient.getValidity(token).isValid()) {
			log.info("deleting tweet of given tweetId");
			tweetService.deleteTweet(tweetId);}
		else {
			throw new UnauthorizedException("Session Expired");
		}
	}
	@GetMapping("/getAllTweet")
	public List<Tweet> displayAllTweet(@RequestHeader("Authorization") String token) {
		if (authClient.getValidity(token).isValid()) {
			log.info("retrieving all tweets");
			return tweetService.getAllTweets();}
		else {
			throw new UnauthorizedException("Session Expired");
		}
	}
	//***** Comment Service Requests********
	@PostMapping("/replyTweet/{tweetId}")
	public void addComment(@PathVariable("tweetId") int tweetId,@RequestHeader("Authorization") String token, @RequestBody Comment comment) {
		if (authClient.getValidity(token).isValid()) {
			log.info("adding comment to given tweetId");
			 commentService.addComment(tweetId, comment);}
		else {
			throw new UnauthorizedException("Session Expired");
		}
	}
	@GetMapping("/getAllReply/{tweetId}")
	public List<Comment> getAllReplyOfTweet(@PathVariable("tweetId") int tweetId, @RequestHeader("Authorization") String token){
		if (authClient.getValidity(token).isValid()) {
			log.info("updating tweet description of given tweet");
			 return commentService.getAllCommentsOfTweet(tweetId);}
		else {
			throw new UnauthorizedException("Session Expired");
		}
	}
}
