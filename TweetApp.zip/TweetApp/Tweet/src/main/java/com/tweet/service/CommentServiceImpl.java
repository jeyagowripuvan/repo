package com.tweet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweet.exception.TweetNotFoundException;
import com.tweet.model.Comment;
import com.tweet.model.Tweet;
import com.tweet.repository.TweetRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CommentServiceImpl implements CommentService {
	@Autowired
	public TweetRepository tweetRepository;
	
	@Override
	public void addComment(int tweetId, Comment comment) {
		// TODO Auto-generated method stub
		if(!tweetRepository.existsByTweetId(tweetId)){
			throw new TweetNotFoundException("Tweet Not Found");
		}
		Tweet tweet = tweetRepository.findById(tweetId).get();
		log.info("Adding comment to given tweet");
		tweet.getCommentsList().add(comment);
		tweetRepository.save(tweet);
	}

	@Override
	public List<Comment> getAllCommentsOfTweet(int tweetId) {
		// TODO Auto-generated method stub
		if(!tweetRepository.existsByTweetId(tweetId)){
			throw new TweetNotFoundException("Tweet Not Found");
		}
		Tweet tweet = tweetRepository.findById(tweetId).get();
		if (tweet.getCommentsList().size() == 0) {
			log.info("Add your comment");
		}
		log.info("Retrieving list of comments of given tweet");
		List<Comment> commentsList = tweet.getCommentsList();
		return commentsList;
	}

}
