package com.tweet.exception;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.tweet.model.MessageResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class RestExceptionHandler {

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(TweetNotFoundException.class)
	public ResponseEntity<?> handleTweetNotFoundExceptions(TweetNotFoundException ex) {
		String errorMessage = ex.getMessage();
		log.error(errorMessage);
		return ResponseEntity.badRequest().body(new MessageResponse(ex.getMessage(), HttpStatus.NOT_FOUND));
	}
	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<?> handleUserNotFoundExceptions(UserNotFoundException ex) {
		String errorMessage = ex.getMessage();
		log.error(errorMessage);
		return ResponseEntity.badRequest().body(new MessageResponse(ex.getMessage(), HttpStatus.NOT_FOUND));
	}
	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(UnauthorizedException.class)
	public ResponseEntity<?> handleUnauthorizedExceptions(UnauthorizedException ex) {
		String errorMessage = ex.getMessage();
		log.error(errorMessage);
		return ResponseEntity.badRequest().body(new MessageResponse(ex.getMessage(), HttpStatus.UNAUTHORIZED));
	}

}
