package com.tweet.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestExceptionHandlerTest {

	@InjectMocks
	RestExceptionHandler restExceptionHandler;
	
	@Test
	void handleUnauthorizedExceptionsTest() {
		assertEquals(restExceptionHandler.handleUnauthorizedExceptions(new UnauthorizedException(null)).getStatusCodeValue(), 400);
	}
	@Test
	void handleTweetNotFoundExceptionsTest() {
		assertEquals(restExceptionHandler.handleTweetNotFoundExceptions(new TweetNotFoundException(null)).getStatusCodeValue(), 400);
	}
	@Test
	void handleUserNotFoundExceptionsTest() {
		assertEquals(restExceptionHandler.handleUserNotFoundExceptions(new UserNotFoundException(null)).getStatusCodeValue(), 400);
	}

}
