package com.tweet.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.tweet.exception.TweetNotFoundException;
import com.tweet.exception.UserNotFoundException;
import com.tweet.model.Comment;
import com.tweet.model.Tweet;
import com.tweet.repository.TweetRepository;

@SpringBootTest
class TweetServiceImplTest {
	@InjectMocks
	TweetServiceImpl tweetService;
	@Mock
	public TweetRepository tweetRepository;

	@Test
	void getTweetTest() {
		List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		Optional<Tweet> data = Optional.of(tweet);
		when(tweetRepository.existsByTweetId(1)).thenReturn(true);
		when(tweetRepository.findById(1)).thenReturn(data);
		assertEquals(tweetService.getTweet(1), tweet);
	}

	@Test
	void getTweetExceptionTest() {
		when(tweetRepository.existsByTweetId(1)).thenReturn(false);
		assertThrows(TweetNotFoundException.class, () -> tweetService.getTweet(1));
	}

	@Test
	void getAllTweetsOfUserTest() {
		List<Tweet> tweetList = new ArrayList<Tweet>();
		when(tweetRepository.existsByUserId("admin")).thenReturn(true);
		assertEquals(tweetService.getAllTweetsOfUser("admin"), tweetList);
	}
	@Test
	void getAllTweetsOfUserExceptionTest() {
		when(tweetRepository.existsByUserId("admin")).thenReturn(false);
		assertThrows(UserNotFoundException.class, ()->tweetService.getAllTweetsOfUser("admin"));
	}
	@Test
	void getAllTweetsTest() {
		List<Tweet> tweetList = new ArrayList<Tweet>();
		when(tweetRepository.findAll()).thenReturn(tweetList);
		assertEquals(tweetService.getAllTweets(), tweetList);
	}
	@Test
	void updateTweetDescriptionTest() {
		List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		Optional<Tweet> data = Optional.of(tweet);
		when(tweetRepository.existsByTweetId(1)).thenReturn(true);
		when(tweetRepository.findById(1)).thenReturn(data);
		tweetService.updateTweetDescription("sample", 1);
	}
	@Test
	void updateTweetDescriptionFailedTest() {
		when(tweetRepository.existsByTweetId(1)).thenReturn(false);
		assertThrows(TweetNotFoundException.class, ()->tweetService.updateTweetDescription("sample", 1));
	}
	@Test 
	void updateTweetLikesCountTest() {
		List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		Optional<Tweet> data = Optional.of(tweet);
		when(tweetRepository.existsByTweetId(1)).thenReturn(true);
		when(tweetRepository.findById(1)).thenReturn(data);
		tweetService.updateTweetLikesCount(1, 1);
	}
	@Test
	void updateTweetLikesCountFailedTest() {
		when(tweetRepository.existsByTweetId(1)).thenReturn(false);
		assertThrows(TweetNotFoundException.class, ()->tweetService.updateTweetLikesCount(1, 1));
	}
	@Test
	void addTweetTest() {
		List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		tweetService.addTweet(tweet);
	}
	@Test
	void deleteTweetTest() {
		when(tweetRepository.existsByTweetId(1)).thenReturn(true);
		tweetService.deleteTweet(1);
	}
	@Test
	void deleteTweetFailedTest() {
		when(tweetRepository.existsByTweetId(1)).thenReturn(false);
		assertThrows(TweetNotFoundException.class, ()->tweetService.deleteTweet(1));
	}
}
