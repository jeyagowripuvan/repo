package com.tweet.service;

import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.tweet.exception.TweetNotFoundException;
import com.tweet.model.Comment;
import com.tweet.model.Tweet;
import com.tweet.repository.TweetRepository;

@SpringBootTest
class CommentServiceImplTest {
	@InjectMocks
	CommentServiceImpl commentServiceImpl;
	@Mock
	public TweetRepository tweetRepository;
	@Test
	void addCommentTest() {
		Comment comment = new Comment("sample","sample");
		when(tweetRepository.existsByTweetId(1)).thenReturn(true);
		List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		Optional<Tweet> data = Optional.of(tweet);
		when(tweetRepository.findById(1)).thenReturn(data);
		commentServiceImpl.addComment(1, comment);
	}
	@Test
	void addCommentExceptionTest() {
		Comment comment = new Comment("sample","sample");
		when(tweetRepository.existsByTweetId(1)).thenReturn(false);
		assertThrows(TweetNotFoundException.class,()-> commentServiceImpl.addComment(1, comment));
	}
	@Test
	void getAllCommentsOfTweetTest() {
		List<Comment> commentList = new ArrayList<Comment>();
		when(tweetRepository.existsByTweetId(1)).thenReturn(true);
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		Optional<Tweet> data = Optional.of(tweet);
		when(tweetRepository.findById(1)).thenReturn(data);
		assertEquals(commentServiceImpl.getAllCommentsOfTweet(1),commentList);
	}
	@Test
	void getAllCommentsOfTweetFailedTest() {
		when(tweetRepository.existsByTweetId(1)).thenReturn(false);
		assertThrows(TweetNotFoundException.class,()-> commentServiceImpl.getAllCommentsOfTweet(1));
	}

}
