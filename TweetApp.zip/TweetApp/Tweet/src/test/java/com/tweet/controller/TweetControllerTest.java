package com.tweet.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.tweet.client.AuthClient;
import com.tweet.exception.UnauthorizedException;
import com.tweet.model.AuthResponse;
import com.tweet.model.Comment;
import com.tweet.model.Tweet;
import com.tweet.service.CommentServiceImpl;
import com.tweet.service.TweetServiceImpl;

@SpringBootTest
class TweetControllerTest {
	@InjectMocks
	public TweetController tweetController;
	@Mock
	public TweetServiceImpl tweetService;
	@Mock
	public CommentServiceImpl commentService;
	@Mock
	public AuthClient authClient;

	@Test
	void postTweetTest() {
		List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(authClient.getValidity("token")).thenReturn(auth);
		when(tweetService.addTweet(tweet)).thenReturn(tweet);
		assertEquals(tweetController.postTweet("token", tweet), tweet);
	}

	@Test
	void postTweetFailedTest() {
		List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(authClient.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, () -> tweetController.postTweet("token", tweet));
	}

	@Test
	void getTweetTest() {
		List<Comment> commentList = new ArrayList<Comment>();
		Tweet tweet = new Tweet(1, "sample", 1, "sample", "admin", commentList);
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(authClient.getValidity("token")).thenReturn(auth);
		when(tweetService.getTweet(1)).thenReturn(tweet);
		assertEquals(tweetController.getTweet(1, "token"), tweet);
	}

	@Test
	void getTweetFailedTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(authClient.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, () -> tweetController.getTweet(1, "token"));
	}

	@Test
	void getAllTweetsOfUserTest() {
		List<Tweet> tweetList = new ArrayList<Tweet>();
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(authClient.getValidity("token")).thenReturn(auth);
		when(tweetController.getAllTweetsOfUser("admin", "token")).thenReturn(tweetList);
		assertEquals(tweetController.getAllTweetsOfUser("admin", "token"), tweetList);
	}

	@Test
	void getAllTweetsOfUserFailedTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(authClient.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, () -> tweetController.getAllTweetsOfUser("admin", "token"));
	}

	@Test
	void updateTweetDescriptionTest() {

		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(authClient.getValidity("token")).thenReturn(auth);
		tweetController.updateTweetDescription(1, "token", "sample");

	}

	@Test
	void updateTweetDescriptionFailedTest() {

		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(authClient.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, () -> tweetController.updateTweetDescription(1, "token", "sample"));

	}
	@Test
	void updateLikeCountTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(authClient.getValidity("token")).thenReturn(auth);
		tweetController.updateLikeCount(1, 1, "token");
	}
	@Test
	void updateLikeCountFailedTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(authClient.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, () -> tweetController.updateLikeCount(1, 1, "token"));
	}
	@Test
	void deleteTweetTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(authClient.getValidity("token")).thenReturn(auth);
		tweetController.deleteTweet("token", 1);
	}
	@Test
	void deleteTweetFailedTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(authClient.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, () -> tweetController.deleteTweet("token", 1));
	}
	@Test
	void displayAllTweetTest() {
		List<Tweet> tweetList = new ArrayList<Tweet>();
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(authClient.getValidity("token")).thenReturn(auth);
		when(tweetController.displayAllTweet("token")).thenReturn(tweetList);
		assertEquals(tweetController.displayAllTweet("token"), tweetList);
	}
	@Test
	void displayAllTweetExceptionTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(authClient.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, () -> tweetController.displayAllTweet("token"));
	}
	@Test
	void addCommentTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(authClient.getValidity("token")).thenReturn(auth);
		Comment comment = new Comment("sample","sample");
		tweetController.addComment(1, "token", comment);
	}
	@Test
	void addCommentFailedTest() {
		Comment comment = new Comment("sample","sample");
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(authClient.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, () -> tweetController.addComment(1, "token", comment));
	}
	@Test
	void getAllReplyOfTweetTest() {
		List<Comment> commentList = new ArrayList<Comment>();
		AuthResponse auth = new AuthResponse("admin", "admin", true);
		when(authClient.getValidity("token")).thenReturn(auth);
		when(tweetController.getAllReplyOfTweet(1, "token")).thenReturn(commentList);
		assertEquals(tweetController.getAllReplyOfTweet(1, "token"), commentList);
	}
	@Test
	void getAllReplyOfTweetFailedTest() {
		AuthResponse auth = new AuthResponse("admin", "admin", false);
		when(authClient.getValidity("token")).thenReturn(auth);
		assertThrows(UnauthorizedException.class, () -> tweetController.getAllReplyOfTweet(1, "token"));
	}
	
}
